# Clean Horizon website — Data & Tools page: developer handoff

> **Résumé (FR).** Dossier de passation de la page **Data & Tools** (`/solutions/data-and-tools`), à fusionner dans le dépôt du nouveau site créé avec le dossier de la home (Astro + Sanity). Il contient : le template commun des quatre pages solutions, la spec bloc par bloc de la page, le texte complet en JSON, une page HTML/CSS de référence responsive qui s'ouvre dans n'importe quel navigateur, les fichiers sources du design, les images, et le schéma Sanity du template. Les points à trancher avant la mise en ligne sont dans `docs/08-data-and-tools-open-items.md`. **Gardez le dépôt privé** : les logos de clients et de banques ne sont pas encore validés pour un usage public.

This folder adds the **Data & Tools** solution page to the repository created from the home page dossier. Its paths mirror that repository: copy each folder onto the folder of the same name.

**Keep the repository private.** `assets/logos` holds client and lender logos that are **not** cleared for public use, and `docs/08-data-and-tools-open-items.md` lists unresolved claims.

## Start here
1. **See the page:** open `web/reference/data-and-tools.html` in a browser. Resize the window below 760 px to see the mobile layout.
2. **Read the template:** `docs/06-solution-page-template.md`. The same 12 blocks will serve Energy Storage Strategy, Economic Advisory and Technical Advisory.
3. **Build the page:** `docs/07-data-and-tools-spec.md`, block by block: content source, layout, responsive rules, links, SEO, structured data, tracking.
4. **Before launch:** `docs/08-data-and-tools-open-items.md`.

## What is in the folder
```
docs/
  06-solution-page-template.md       the 12-block template shared by the 4 solution pages
  07-data-and-tools-spec.md          the page, block by block (layout, responsive, links, SEO, JSON-LD, tracking)
  08-data-and-tools-open-items.md    what must be settled before launch
  09-data-and-tools-sources.md       where each piece of content comes from
content/
  data-and-tools.json                SOURCE of the copy (structured, with hrefs)
  data-and-tools.md                  readable version, generated from the JSON
web/reference/
  data-and-tools.html                static reference build: responsive HTML/CSS + JSON-LD, no JS
studio/schemas/
  solutionPage.ts                    Sanity schema for the solution template
design/data-and-tools/               design source files (Claude Design canvas) + asset map
tools/
  build_reference.py                 regenerates web/reference/ from design/ + content/
  content_md.py                      regenerates content/data-and-tools.md from the JSON
assets/
  brand/   logo, watermark shape, ISO 27001 badge
  logos/   18 client and lender logos used on the page
  images/  coverage map (18 price-forecast countries, one colour)
```

## How to use each piece
| Piece | Use it for | Do not |
|---|---|---|
| `web/reference/data-and-tools.html` | The look, spacing, breakpoints and behaviour to reproduce | Ship it: styles are inline, copied one-to-one from the design file |
| `content/data-and-tools.json` | Seeding Sanity, or as props for the Astro components | Edit `data-and-tools.md` instead (it is generated) |
| `studio/schemas/solutionPage.ts` | Adding the `solutionPage` document type to the Studio | Assume it has run: it is type-checked only (see Status) |
| `design/data-and-tools/*.dc.html` | Checking a detail of the design against the source | Open them as plain HTML: they need the design runtime |
| `tools/*.py` | Regenerating the readable copy and the reference page after a JSON or design change: `python3 tools/content_md.py .` then `python3 tools/build_reference.py .` (Python 3, no dependency) | Edit the generated files by hand |

In the reference page, links take their targets from the JSON. The nine links whose target is not decided yet (Resources, About, Login, burger, Hertz story, and four footer links) keep `href="#"` and carry a `data-href-todo` attribute: search for it.

## Changes to apply to files of the home dossier
These come from decisions taken on 14 October 2026, after the home dossier was delivered.
1. **`docs/01-sitemap.md`:** set *Security and expertise* (`/about/security-and-expertise`) to **V1**. The Data & Tools page links to it. Its final name is still open (see open items).
2. **`docs/01-sitemap.md`:** set the Data & Tools row's design status to "Desktop 1440 + mobile 390".
3. **Navigation content (`home.json`, `navigation`):**
   - Data & Tools description: remove "and CHESS". CHESS is not presented on the site.
   - Storage Index description: remove "in 10 markets". The only coverage figure kept is "18 countries".
4. **Home copy:** the same two points apply to the home page (offers block, Storage Index block, FAQ "How do I access your data?" and "Which markets do you cover?").
5. **Assets:** if a logo here already exists in the home `assets/logos`, keep one copy and point both pages to it. `saarlb.svg` is new.

## Rules carried over from the home dossier
- **Placeholders:** any text containing `[` is a placeholder. A build that renders one must fail. The schema refuses them at publish time.
- **Logos:** only logos flagged `approvedForPublicUse` are rendered.
- **Quotes and client figures:** shown only once the client has approved them (Kallista quote, the 120 MW / 2h figures, the Hertz story).
- **One H1 per page.** This page's H1 must never reuse a home page sentence.

## Status
| Area | State |
|---|---|
| Copy | Final, except the square-bracket placeholders listed in `docs/08` |
| Design | Desktop 1440 and mobile 390 (one responsive source). No tablet-specific design |
| Reference page | Rendered and checked in Chromium at 1440 px and 390 px: no horizontal overflow |
| Sanity schema | Type-checked with `sanity` 6.19 and TypeScript strict. **Not run in a Studio** |
| Astro | No component written for this page. Build it from the spec and the reference page with the site's components |
| Sub-pages | Price Forecast, COSMOS and Storage Index pages are not designed. A COSMOS video exists and is reserved for the COSMOS page |

## Contacts
Marketing director: owner of copy, positioning and sign-offs. (Add names and e-mails here.)
