/**
 * solutionPage — one document per solution page (Data & Tools, Energy Storage Strategy,
 * Economic Advisory, Technical Advisory). Implements the 12-block template of
 * docs/06-solution-page-template.md.
 *
 * Fixed blocks share the same shape on every page. Blocks 4 (offer), 5 (method) and
 * 10 (howToBuy) are variable: each holds an array whose member types differ by page.
 *
 * References assume the document types of the home dossier: `logo` (with
 * `approvedForPublicUse`), `customerStory`, `faqItem`, and the `seo` object.
 * Rename them here if the studio uses other names.
 *
 * Status: written and type-checked against `sanity`, NOT run in a Studio.
 */
import {defineArrayMember, defineField, defineType} from 'sanity'

const link = (name: string, title: string) =>
  defineField({
    name,
    title,
    type: 'object',
    fields: [
      defineField({name: 'label', type: 'string', validation: (r) => r.required()}),
      defineField({
        name: 'href',
        type: 'string',
        description: 'Internal path (/solutions/…), in-page anchor (#contact) or full URL',
        validation: (r) => r.required(),
      }),
    ],
  })

/** Block any string containing "[" (unfilled placeholder) from being published. */
const noPlaceholder = (r: any) =>
  r.custom((v: unknown) =>
    typeof v === 'string' && v.includes('[') ? 'Placeholder "[…]" left in the text' : true,
  )

const text = (name: string, title?: string, rows = 3) =>
  defineField({name, title, type: 'text', rows, validation: noPlaceholder})
const str = (name: string, title?: string) =>
  defineField({name, title, type: 'string', validation: noPlaceholder})

export const solutionPage = defineType({
  name: 'solutionPage',
  title: 'Solution page',
  type: 'document',
  groups: [
    {name: 'top', title: '1–3 · Hero, proof, challenges', default: true},
    {name: 'offer', title: '4–5 · Offer and method'},
    {name: 'proof', title: '6–9 · Proof, relay, stories, coverage'},
    {name: 'convert', title: '10–12 · How to buy, FAQ, contact'},
    {name: 'seo', title: 'SEO'},
  ],
  fields: [
    str('title', 'Internal title'),
    defineField({name: 'slug', type: 'slug', options: {source: 'title'}, validation: (r) => r.required()}),
    defineField({
      name: 'order',
      type: 'number',
      description: 'Position in the sticky solutions bar (1 = Data & Tools)',
    }),
    defineField({
      name: 'expertLabel',
      type: 'string',
      description: 'Used in every primary CTA: "Talk to a … expert" (data / strategy / economic advisory / technical)',
    }),

    // 1 · Hero
    defineField({
      name: 'hero',
      type: 'object',
      group: 'top',
      fields: [
        str('eyebrow'),
        defineField({
          name: 'h1',
          type: 'string',
          description: 'Carries the page keyword. Must not reuse a home page sentence.',
          validation: (r) => r.required().max(90),
        }),
        text('subtitle'),
        link('primaryCta', 'Primary CTA'),
        link('secondaryCta', 'Secondary CTA'),
        defineField({name: 'proofPoints', type: 'array', of: [{type: 'string'}], validation: (r) => r.max(3)}),
        defineField({name: 'visual', type: 'image', options: {hotspot: true}, fields: [str('alt'), str('caption')]}),
      ],
    }),

    // 2 · Proof band
    defineField({
      name: 'proofBand',
      type: 'object',
      group: 'top',
      fields: [
        str('title'),
        defineField({
          name: 'stats',
          type: 'array',
          validation: (r) => r.max(3),
          of: [defineArrayMember({type: 'object', fields: [str('value'), str('label')]})],
        }),
        defineField({
          name: 'logos',
          type: 'array',
          description: 'One marquee line. Only logos with approvedForPublicUse are rendered.',
          of: [defineArrayMember({type: 'reference', to: [{type: 'logo'}]})],
        }),
      ],
    }),

    // 3 · Challenges
    defineField({
      name: 'challenges',
      type: 'object',
      group: 'top',
      fields: [
        str('title'),
        text('intro', undefined, 2),
        defineField({
          name: 'items',
          type: 'array',
          validation: (r) => r.length(4),
          of: [
            defineArrayMember({
              type: 'object',
              fields: [
                defineField({
                  name: 'audience',
                  type: 'string',
                  options: {list: ['Developers', 'IPPs and utilities', 'Investors and lenders', 'Battery suppliers']},
                }),
                text('challenge'),
                text('answer', undefined, 2),
                link('link', 'Link'),
              ],
            }),
          ],
        }),
        str('closing'),
      ],
    }),

    // 4 · Offer (variable)
    defineField({
      name: 'offer',
      type: 'object',
      group: 'offer',
      fields: [
        str('title'),
        link('link', 'Section link'),
        defineField({
          name: 'items',
          type: 'array',
          description: 'Data & Tools: product cards linking to sub-pages. Advisory pages: services described in place.',
          of: [
            defineArrayMember({
              name: 'productCard',
              type: 'object',
              fields: [
                str('label'),
                str('name'),
                str('tagline'),
                text('body', undefined, 4),
                defineField({name: 'chips', type: 'array', of: [{type: 'string'}]}),
                defineField({
                  name: 'points',
                  type: 'array',
                  of: [defineArrayMember({type: 'object', fields: [str('lead'), str('text')]})],
                }),
                defineField({
                  name: 'levels',
                  type: 'array',
                  description: 'Storage Index only: Free / Nord Pool / Your asset',
                  of: [defineArrayMember({type: 'object', fields: [str('badge'), str('name'), str('text')]})],
                }),
                defineField({name: 'note', type: 'object', fields: [str('lead'), str('text')]}),
                link('primaryCta', 'Primary CTA'),
                link('secondaryCta', 'Secondary CTA'),
                link('secondaryLink', 'Methodology link'),
              ],
            }),
            defineArrayMember({
              name: 'serviceItem',
              type: 'object',
              fields: [str('name'), text('body'), str('deliverable'), defineField({name: 'bullets', type: 'array', of: [{type: 'string'}]})],
            }),
          ],
        }),
      ],
    }),

    // 5 · Method (variable)
    defineField({
      name: 'method',
      type: 'object',
      group: 'offer',
      fields: [
        str('title'),
        text('intro'),
        defineField({
          name: 'steps',
          type: 'array',
          validation: (r) => r.max(4),
          of: [
            defineArrayMember({
              type: 'object',
              fields: [
                str('label'),
                str('title'),
                text('text', undefined, 2),
                defineField({name: 'items', type: 'array', of: [defineArrayMember({type: 'object', fields: [str('title'), str('text')]})]}),
                defineField({name: 'stack', type: 'array', description: 'Revenue-stack labels, top to bottom', of: [{type: 'string'}]}),
                defineField({name: 'then', type: 'array', of: [{type: 'string'}]}),
                str('footnote'),
              ],
            }),
          ],
        }),
        str('footerText'),
        link('footerLink', 'Footer link'),
      ],
    }),

    // 6 · Method proof
    defineField({
      name: 'methodProof',
      type: 'object',
      group: 'proof',
      fields: [
        str('title'),
        link('link', 'Link'),
        defineField({
          name: 'proofs',
          type: 'array',
          of: [
            defineArrayMember({
              type: 'object',
              fields: [
                str('label'),
                defineField({name: 'chartType', type: 'string', options: {list: ['bars', 'range']}}),
                defineField({
                  name: 'values',
                  type: 'array',
                  description: 'bars: one row per bar · range: low, high, then markers',
                  of: [defineArrayMember({type: 'object', fields: [str('label'), str('sublabel'), defineField({name: 'value', type: 'number'})]})],
                }),
                str('unit'),
                text('caption'),
                defineField({name: 'publishable', type: 'boolean', initialValue: false, description: 'Tick only once third-party consent is on file'}),
              ],
            }),
          ],
        }),
        str('disclaimer'),
      ],
    }),

    // 7 · Relay to the next offer
    defineField({
      name: 'relay',
      type: 'object',
      group: 'proof',
      fields: [
        str('eyebrow'),
        str('title'),
        text('intro'),
        defineField({
          name: 'options',
          type: 'array',
          validation: (r) => r.max(3),
          of: [
            defineArrayMember({
              type: 'object',
              fields: [
                str('title'),
                text('text', undefined, 2),
                defineField({name: 'bullets', type: 'array', of: [{type: 'string'}]}),
                defineField({name: 'quote', type: 'reference', to: [{type: 'customerStory'}], description: 'Uses the story quote; shown only if approved'}),
              ],
            }),
          ],
        }),
        defineField({name: 'ctas', type: 'array', of: [defineArrayMember({type: 'object', fields: [str('label'), str('href')]})], validation: (r) => r.max(2)}),
      ],
    }),

    // 8 · Customer stories
    defineField({
      name: 'stories',
      type: 'object',
      group: 'proof',
      fields: [
        str('title'),
        link('link', 'All stories link'),
        defineField({name: 'items', type: 'array', of: [defineArrayMember({type: 'reference', to: [{type: 'customerStory'}]})], validation: (r) => r.max(3)}),
      ],
    }),

    // 9 · Coverage
    defineField({
      name: 'coverage',
      type: 'object',
      group: 'proof',
      fields: [
        str('title'),
        defineField({name: 'items', type: 'array', of: [defineArrayMember({type: 'object', fields: [str('title'), text('text', undefined, 2), str('href')]})]}),
        defineField({name: 'map', type: 'image', fields: [str('alt')]}),
        str('badge'),
        defineField({name: 'countries', type: 'array', of: [{type: 'string'}]}),
        link('cta', 'CTA'),
      ],
    }),

    // 10 · How to buy (variable)
    defineField({
      name: 'howToBuy',
      type: 'object',
      group: 'convert',
      fields: [
        str('title'),
        link('cta', 'CTA'),
        defineField({
          name: 'steps',
          type: 'array',
          validation: (r) => r.length(4),
          of: [defineArrayMember({type: 'object', fields: [str('title'), text('text', undefined, 2)]})],
        }),
        defineField({
          name: 'callout',
          type: 'object',
          description: 'Data & Tools: confidentiality box',
          fields: [str('title'), text('text'), link('link', 'Link'), defineField({name: 'badge', type: 'image'})],
        }),
      ],
    }),

    // 11 · FAQ
    defineField({
      name: 'faq',
      type: 'object',
      group: 'convert',
      fields: [
        str('title'),
        str('intro'),
        defineField({name: 'items', type: 'array', of: [defineArrayMember({type: 'reference', to: [{type: 'faqItem'}]})], validation: (r) => r.min(5).max(8)}),
      ],
    }),

    // 12 · Contact
    defineField({
      name: 'contact',
      type: 'object',
      group: 'convert',
      fields: [
        str('title'),
        text('text', undefined, 2),
        defineField({
          name: 'projectPreset',
          type: 'string',
          options: {list: ['Market entry', 'Business case', 'Feasibility and design', 'Supplier tender', 'Due diligence', 'Data subscription', 'Other']},
        }),
        defineField({name: 'showMarketsField', type: 'boolean', initialValue: false}),
        str('submitLabel'),
      ],
    }),

    defineField({name: 'seo', type: 'seo', group: 'seo'}),
  ],
  preview: {select: {title: 'title', subtitle: 'slug.current'}},
})
