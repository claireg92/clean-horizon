# 07 · Data & Tools page — build spec

| | |
|---|---|
| URL | `/solutions/data-and-tools` |
| Sanity | `solutionPage`, slug `data-and-tools`, order 1, expertLabel "data" |
| Copy | `content/data-and-tools.json` (source) — `content/data-and-tools.md` (readable) |
| Visual reference | `web/reference/data-and-tools.html` |
| Design source | `design/data-and-tools/Main.dc.html` (blocks 1–4) and `Part2.dc.html` (blocks 5–12, footer) |
| Breakpoint | 760 px, container query on the page root |

Copy is not repeated here: each block names its JSON key.

## Header and solutions bar
- **Header:** same as the home. "Solutions" shows as active (grey pill). The header CTA reads **"Talk to a data expert"** and scrolls to `#contact`.
- **Solutions bar** (`solutionNav`): sticky at `top: 0`, white at 96% opacity, four pills. The current page is a navy pill with `aria-current="page"`. It scrolls horizontally when it overflows.
- **Under 760 px:** the main nav, Login and the header CTA are hidden and a 48 px burger shows. The burger should open the mobile menu of the home dossier (`MobileMenu`). It is not wired in the reference page.

## Block 1 · Hero (`hero`)
- Two columns that wrap (`flex: 1 1 520px` text, `flex: 1 1 460px` visual), 56 px gap. Background: white fading to `#E6E9EE` at the bottom.
- Breadcrumb above the eyebrow (`seo.breadcrumb`), with `BreadcrumbList` JSON-LD.
- **H1**, the only one on the page: `clamp(38px, 4vw, 56px)`.
- **Visual:** the design shows a CSS mock of the Clean Horizon Platform (revenue stack bars, NPV `[€ M]`, IRR `[%]`, `[Country]`). **Replace it with a real, anonymised screenshot** in a 24 px radius card with a shadow. Keep the caption "Illustrative example".
- CTAs: primary navy, secondary white with a border.

## Block 2 · Proof band (`proofBand`)
- Title left, two figures right (`18 countries`, `Since 2009`), each with a 2 px navy top rule.
- **One logo marquee line:** 18 logos alternating client and lender (order in the JSON). The list is rendered twice for a seamless loop. The animation is `translateX(0 → −50%)`, linear, infinite, **120 s** per loop. Fade masks cover 8% at each edge. Each logo fits a 150×52 box (max-height 44 px), with a 64 px gap.
- The second copy of the list is `aria-hidden`.
- `prefers-reduced-motion: reduce` stops the animation.
- Render only logos with `approvedForPublicUse`. Crédit Agricole is missing (no file).

## Block 3 · Your challenges (`challenges`)
- Grid `repeat(auto-fit, minmax(260px, 1fr))`, 20 px gap: four columns at 1440 px, one under 760 px.
- Card: white, 1 px `#E6E9EE` border, 28 px radius, light shadow. Each card is a single link to `#tools`, with an audience pill, the challenge in navy bold, a rule, the answer, and a link label.

## Block 4 · Three tools (`tools`, anchor `#tools`)
- Grey section. Grid `repeat(auto-fit, minmax(min(320px, 100%), 1fr))`: three columns, then one.
- Cards stretch to equal height. CTAs are pushed to the bottom (`margin-top: auto`).
- **Price Forecasts:** three points with bold leads, then an "Option" box.
- **COSMOS:** six market chips, three points, a "Coverage" box, then two buttons ("Ask for a demo" navy → `#contact`, "Explore COSMOS" outlined) and the methodology link.
- **Storage Index:** a three-row list with badges (FREE navy, NORD POOL mid blue, YOUR ASSET light blue).
- Each card has a methodology link to `/resources/methodologies#…`. Agree the anchors with the Methodologies page.

## Block 5 · One battery, many markets (`engine`)
- Title and intro on one row, then a three-step diagram:
  - Desktop: CSS grid `1fr 52px 0.9fr 52px 1.4fr`, with arrows in the 52 px columns.
  - Under 760 px: a vertical stack, with the arrows rotated 90°.
- **Step 1:** white card with two grey boxes joined by "+".
- **Step 2:** navy card with the watermark shape.
- **Step 3:** pale card with the **battery**:
  - a 3 px navy outline with a 40×12 cap;
  - six 40 px tall segments in the revenue-stack colours (`docs/06`), each joined by a short rule to a white label pill;
  - under 760 px, the segments shrink from 112 to 64 px wide.
- Then two chips: "Cash flows · NPV · IRR" (navy) and "Optimal sizing".
- All six segments have the same height on purpose: this is not a chart. Do not size them by revenue share.
- The diagram must stay HTML text (not an image) so search engines and AI assistants can read it.
- Footer strip (grey) with the Storage Index sentence and a link to `/resources/methodologies#cosmos`.

## Block 6 · Method proof (`methodProof`)
- Two cards in a grid of `repeat(auto-fit, minmax(min(360px, 100%), 1fr))`.
- **Bars:** two bars whose heights are proportional to the values (270/305 = 88.5%), labelled above, with the period under each bar.
- **Range:** scale €200k–€300k. The real-asset range is a pale band from 211 to 293. A 4 px mid-blue tick marks the [Enspired] average at 255. A navy dot with a white ring marks the Storage Index at 271. Values are placed by computation, never typed as positions.
- The disclaimer goes under the cards.
- **Blocker:** the second card stays hidden until Enspired's written consent (`publishable` in the schema).

## Block 7 · Relay to advisory (`advisoryRelay`)
- Navy panel with a 32 px radius and the watermark shape.
- Three white cards. Card 02 holds the Kallista quote, shown only if it is approved.
- Two CTAs: white, and outlined on navy.

## Block 8 · Customer stories (`customerStories`)
- Same card component as the home page. Two cards: Kallista and Hertz I & II.
- Hide "View all customer stories" while `/customer-stories` is V2.
- The Hertz slug is still to confirm.

## Block 9 · Coverage (`coverage`)
- Grey panel. Text column with three numbered items and a CTA to `#contact`.
- Map card: `assets/images/coverage-map-price-forecasts.svg`, aspect ratio 600/560.
- A navy "18 countries" badge sits over the map, top left. Under 760 px it moves above the map.
- The 18 country pills go under the map, in HTML (SEO).
- **Known issue:** Luxembourg is not visible on the map.

## Block 10 · How a subscription works (`subscription`)
- Four numbered steps (`auto-fit, minmax(240px, 1fr)`), joined by a horizontal rule on desktop. The rule is hidden under 760 px.
- Confidentiality box in pale blue with a lock icon. Its link goes to `/about/security-and-expertise`; the page is now V1 and its name is still to settle.
- The ISO badge placeholder stays out until the certification scope is confirmed.
- "Request pricing" → `#contact`.

## Block 11 · FAQ (`faq`)
- Two columns that wrap. Accordion of seven questions; the first is open.
- In the reference page this is native `<details>`/`<summary>`, which needs no JavaScript and keeps answers in the HTML for crawlers. Keep the answers in the DOM whatever the implementation.
- `FAQPage` JSON-LD comes from the same items.

## Block 12 · Contact (`contact`, anchor `#contact`)
- Same form as the home page, with two changes:
  - "What is your project?" is preselected to **Data subscription**;
  - a new multiselect, **Markets of interest**: the 18 countries plus "Other".
- Hidden fields: `sourcePage`, plus the label of the CTA that brought the visitor (see Tracking).
- The submission target (CRM or form service) is still undecided, as on the home page.
- "[Response time…]" under the button is a placeholder.

## Footer
Same as the home page. "Data & Tools" is highlighted in the Solutions column.

## Links
| From | Label | Target |
|---|---|---|
| Hero, header, cards, coverage, subscription | Talk to a data expert / Ask for a demo / Ask about a market / Request pricing | `#contact` |
| Hero | See the latest Storage Index | `/solutions/data-and-tools/storage-index` |
| Card 1 | Explore Price Forecasts | `/solutions/data-and-tools/price-forecast` |
| Card 2 | Explore COSMOS | `/solutions/data-and-tools/cosmos` |
| Card 3, coverage | See all indexes / Storage Index page | `/solutions/data-and-tools/storage-index` |
| Cards, block 5, block 6, FAQ | Methodology links | `/resources/methodologies` + `#price-forecasts`, `#cosmos`, `#storage-index`, `#backtests` |
| Block 7 | Explore Economic / Technical Advisory | `/solutions/economic-advisory`, `/solutions/technical-advisory` |
| Block 8 | Stories | `/customer-stories/kallista-energy-saleux-120-mw-battery`, `/customer-stories/[hertz slug]` |
| Block 10 | Security and confidentiality | `/about/security-and-expertise` |

## SEO
| Item | Value |
|---|---|
| Title (58 characters) | Electricity Price Forecasts & Revenue Data \| Clean Horizon |
| Meta description (134 characters) | Electricity price forecasts in 18 countries, COSMOS revenue simulation and the monthly Storage Index, for storage and hybrid projects. |
| Canonical | `https://www.cleanhorizon.com/solutions/data-and-tools` (domain to confirm) |
| Queries targeted by this hub | electricity price forecast Europe, ancillary services price forecast, BESS revenue forecast |
| Queries left to sub-pages | price forecast + country; BESS revenue simulation software; battery storage index, BESS revenues + country |
| Open Graph image | to produce (1200×630) |
| 301 redirects from the current site | `/solutions/` and its anchors `#price_forecast`, `#cosmos`, `#premium_index`; `/services/cosmos/`; `/battery-index/#methodology` → Methodologies |

**Structured data** (all four are in `<head>` of the reference page and are generated from the JSON):
- `Service`: provider `Organization` Clean Horizon, `areaServed` = the 18 countries;
- `ItemList`: the three products with their sub-page URLs;
- `BreadcrumbList`;
- `FAQPage`: the seven questions.

**GEO (AI assistants):**
- COSMOS is spelled out at its first mention.
- Every figure carries a unit and a period.
- FAQ answers read on their own.
- All text is HTML, including the diagram and the country list.

## Tracking
Analytics tool not decided (same as the home page). Events to send:
| Event | When | Properties |
|---|---|---|
| `cta_click` | Any CTA or link listed in the table above | `label`, `block` (1–12), `target` |
| `solution_nav_click` | Pill of the sticky bar | `target` |
| `faq_open` | A FAQ item opened | `question` |
| `form_submit` | Contact form sent | `project`, `markets[]`, `ctaClicked`, `sourcePage` |
| `outbound_click` | Nord Pool, LinkedIn, YouTube | `url` |

Store the label of the last `#contact` CTA clicked and send it as `ctaClicked` with the form. It tells sales whether a lead came for a demo, pricing or a market.

## Accessibility
- Every interactive element is a real `<a>`, `<button>`, `<summary>` or form control. Labels are tied to inputs.
- Decorative images (watermark shape, battery outline) carry `alt=""` or `aria-hidden`.
- Text on navy uses white or `#ABC9E1` (both above 4.5:1).
- Both animations respect `prefers-reduced-motion`.
