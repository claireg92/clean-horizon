# 08 · Data & Tools page: open items before launch

Status on 14 October 2026. Nothing marked **Blocker** goes live unanswered. The developer can build everything now; these items only change copy, assets or flags.

How to read the "Build impact" column:
- **Flag**: the component exists, a boolean or `approvedForPublicUse` hides it until cleared.
- **Placeholder**: the string contains `[` and the build fails until it is filled (see README rules).
- **Copy**: a text change in `content/data-and-tools.json` or in Sanity, no code change.

## A. Claims and figures

| # | Item | What the sources say | What the page says now | Owner | Build impact | Level |
|---|---|---|---|---|---|---|
| A1 | Enspired comparison (block 6, second card) | Third-party data from an internal slide (Germany, Q2 2026) | `[Enspired]` in brackets | Marketing → Enspired: written consent | Flag `publishable` + Placeholder | **Blocker** |
| A2 | Price-forecast coverage, 18 countries | Q4 deck: 18. Q3 deck and current site (May 2026): 14 to 16 | "18 countries" everywhere | Data team: are Great Britain and Bulgaria delivered today? | Copy | **Blocker** |
| A3 | COSMOS coverage | October 2026 COSMOS video: 18 countries. Current site: 26 countries, including Japan | 18 countries, aligned on the video | Data team: which figure is current | Copy | **Blocker** |
| A4 | "86% accuracy" (backtest France 2025) | The figures on the same slide (270 and 267 vs 305 k€/MW/yr) give 88% and 87%, not 86% | Raw figures only, no percentage | Data team: correct the deck | None on the page | To fix in the deck |
| A5 | Storage Index coverage | Q4 deck: 10 markets. Storage Index deck: 15 countries in Q1 2026 | No figure, link to the Storage Index page | Data team | None on this page. The home shows "10": see D2 | To align |
| A6 | Price forecasts beyond storage | Current site and decks describe storage projects (and hybrids for COSMOS). Nothing on stand-alone solar or wind | "Electricity price forecasts", no asset named | Marketing: which other assets to name, if any | Copy | Open |
| A7 | "Bankable / approved by lenders" | Said in the COSMOS video; no written source with lender names | Not used on this page | Marketing | None | Keep out until sourced |
| A8 | Battery suppliers as an audience | Project brief: they buy forecasts | The "several markets" challenge of the current site is assigned to suppliers | Marketing | Copy | To confirm |
| A9 | Response time under the form button | No source | `[Response time to validate with the sales team.]` | Sales | Placeholder | **Blocker** |

## B. Clients, logos and stories

| # | Item | Owner | Build impact | Level |
|---|---|---|---|---|
| B1 | Every logo in the marquee (10 clients, 8 lenders): written approval for public use | Marketing, per client and per bank | Flag `approvedForPublicUse`; unapproved logos are simply not rendered | **Blocker** per logo |
| B2 | Crédit Agricole (lender on the Enertrag project): no logo file | Marketing | Add the file + `logo` document | Open |
| B3 | Kallista quote (block 7, card 02) and figures 120 MW / 2h (block 8) | Kallista | Flag on the story; the quote is hidden if not approved | **Blocker** for the quote |
| B4 | Hertz I & II story (Estonia): approval and final slug | Marketing | Placeholder in `customerStories.cards[1].href`. The card links nowhere until set | **Blocker** for that card |
| B5 | "View all customer stories" link | — | Hidden while `/customer-stories` is V2 | Flag |

## C. Assets to produce

| # | Item | Spec | Owner | Level |
|---|---|---|---|---|
| C1 | Hero visual | Real, anonymised screenshot of the Clean Horizon Platform. Replaces the CSS mock in the design. Caption "Illustrative example" stays | Data team + Marketing | **Blocker** |
| C2 | Coverage map | Luxembourg is not visible at this scale. Add an inset or a marker, or accept that the HTML list carries it | Design | To fix |
| C3 | Open Graph image | 1200×630, `seo.ogImage` | Design | Before launch |
| C4 | ISO 27001 badge (block 10) | Only if the certification scope covers the platform. Badge file is in `assets/brand` | Management / IT: exact scope | Placeholder, kept out until confirmed |

## D. Site-level decisions (shared with the home dossier)

| # | Item | Notes | Owner |
|---|---|---|---|
| D1 | Security page name and URL | Linked as `/about/security-and-expertise`, now **V1**. Final name to settle; keep a 301 if the slug changes | Marketing |
| D2 | Home and navigation copy | Remove "and CHESS" and "in 10 markets" (README, "Changes to apply") | Developer, once approved |
| D3 | Form submission target | CRM or form service not chosen, same as the home | Marketing + Sales |
| D4 | Analytics tool | Not chosen. Events are specified in `docs/07` | Marketing |
| D5 | Methodologies page anchors | `#price-forecasts`, `#cosmos`, `#storage-index`, `#backtests` must exist on `/resources/methodologies` | Whoever builds that page |
| D6 | Sub-pages | `/solutions/data-and-tools/price-forecast`, `/cosmos`, `/storage-index` are not designed. The current Storage Index page (2,000+ visits a month) must keep its traffic: 301 from the old URL | Marketing + Developer |
| D7 | Header links with no target yet | Resources, About, Login, burger menu, and footer Market Insights, Events & Webinars, Legal notice, Privacy: `href="#"` with `data-href-todo` in the reference page. Take the targets from `docs/01-sitemap.md` of the home dossier | Developer |
| D8 | Domain for canonical and JSON-LD | `https://www.cleanhorizon.com` assumed | Developer |
| D9 | Pricing and lead magnet | Not decided: whether prices are shown (the page says "Request pricing"), and whether this page gets a downloadable lead magnet besides the free Storage Index | Marketing |

## E. Already resolved (for the record)
- COSMOS video: received 14 October 2026. It feeds the COSMOS card, coverage and FAQ, and is **reserved for the future COSMOS page**: do not embed it here.
- CHESS: not presented on the site.
- Coverage figure: only "18 countries" is used.
- H1: different from every home page sentence.
- "Projects where…" references table: removed. Logos form a single marquee line.
