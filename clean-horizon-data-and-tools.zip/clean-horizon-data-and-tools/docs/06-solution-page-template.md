# 06 · Solution page template

One template serves the four solution pages: **Data & Tools**, **Energy Storage Strategy**, **Economic Advisory**, **Technical Advisory**. It has 12 blocks in a fixed order. The visitor recognises their situation, sees what they buy, checks that it holds, then acts.

Only blocks 4, 5 and 10 change shape from one page to the next. Data & Tools is a hub of three products with their own sub-pages; the advisory pages are services without sub-pages. Block 4 absorbs that difference.

Sanity: one `solutionPage` document per page (`studio/schemas/solutionPage.ts`).

## The 12 blocks

| # | Block | Role in the funnel | Fixed or variable | Data & Tools | Advisory pages |
|---|---|---|---|---|---|
| — | Header + sticky solutions bar | Navigate between the four offers | Fixed | Current offer highlighted | Same |
| 1 | Hero | Say what is bought, with the page keyword | Fixed | Promise, 2 CTAs, platform visual | Promise, 2 CTAs, project visual |
| 2 | Proof band | Answer "who are these people" | Fixed shape, content per offer | Title, 2 figures, one logo marquee (clients and lenders) | Same, logos of the offer's missions |
| 3 | Your challenges | Make the visitor recognise their decision | Fixed: 4 cards | One per audience: developers, IPPs, investors and lenders, battery suppliers | Same audiences |
| 4 | The offer | Show what is bought | **Variable** | 3 product cards, each linking to its sub-page and to Methodologies | 3 to 4 services described in place, with the deliverable |
| 5 | How it works | Make the method visible | **Variable** | 3-step diagram: what goes in → COSMOS → revenue forecast by market | Steps of an assignment, from question to deliverable |
| 6 | Method proof | Show it holds against reality | Fixed | Two backtests as small charts | Anonymised extracts of deliverables |
| 7 | Relay | Move the visitor to the next offer | Fixed, direction reversed | From data to advisory | From advisory to subscription |
| 8 | Customer stories | Prove with named projects | Fixed | 2 story cards tagged Data & Tools | Story cards tagged with the offer |
| 9 | Coverage | Answer "do you cover my market?" | Fixed | Map of the 18 price-forecast countries + list | Countries delivered directly or through partners |
| 10 | How to work with us | Remove purchase friction | **Variable** | Subscription in 4 steps + confidentiality box | Assignment in 4 steps |
| 11 | FAQ | Handle objections; SEO and AI assistants | Fixed: 5 to 8 questions | Product FAQ | Assignment FAQ |
| 12 | Final call to action | One gesture | Fixed | Home contact form, "Data subscription" preselected, + "Markets of interest" | Same form, offer preselected |
| — | Footer | | Fixed | Same as home | Same as home |

## Rules
1. **One H1, carrying the page keyword.** Unlike the home page, a solution page must rank on a search. It never reuses a home page sentence (duplicate content).
2. **Two CTAs at most per block.** The primary CTA is the same across the page: "Talk to a [data / strategy / economic advisory / technical] expert".
3. **The four audiences appear as labels in block 3**, not as separate paths (decision taken for the home page).
4. **Every figure has a named internal source** (`docs/09`), and every named client has approved its mention.
5. **The sticky solutions bar** stays at the top of the viewport while scrolling, as on the home page.
6. **Nothing invented.** Missing facts stay as `[placeholders]` and block publication.

## Shared design tokens (same as the home dossier)
| Token | Value | Use |
|---|---|---|
| Navy | `#003F89` | Headings, primary buttons, dark panels |
| Mid blue | `#2B6DB1` | Eyebrows, links, accents |
| Light blue | `#ABC9E1` | Text on navy, borders |
| Pale blue | `#D3E1EE` | Callout boxes |
| Grey | `#E6E9EE` | Section backgrounds, chips, dividers |
| Text | `#2F3747` | Body text |
| Font | Calibri, fallback Carlito (Google Fonts), then `'Segoe UI', sans-serif` | All text, 400 and 700 |
| Radii | 999 px (pills, nav), 14 px (buttons), 20–28 px (cards), 32 px (panels) | |
| Container | max-width 1440 px, side padding `clamp(20px, 4.5vw, 64px)` | |
| Section rhythm | 104 px top and bottom on desktop, 64 px under 760 px | |
| H2 | `clamp(36px, 3.6vw, 54px)`, line-height 1.04, letter-spacing −0.015em | |

Revenue-stack colours (block 5, taken from the COSMOS video): mFRR `#DDE3EC`, aFRR `#B9D3F5`, FCR `#8DB8F0`, Intraday `#6AA2EC`, Day-Ahead `#4A8BE8`, Capacity market `#2575E6`.

## Responsive rule
One breakpoint: **760 px**, applied with a CSS container query on the page root (`container-type: inline-size`). Below it the header shows a burger, grids become one column, the block 5 diagram stacks vertically, and sections tighten to 64 px. Details per block in `docs/07`.
