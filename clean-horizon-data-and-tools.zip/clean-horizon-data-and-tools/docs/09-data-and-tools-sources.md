# 09 · Data & Tools page: where the content comes from

Rule: nothing on the page is invented. Every sentence and figure comes from one of the internal sources below. A fact that no source gives stays as a `[placeholder]` (listed in `docs/08`).

These sources are internal Clean Horizon documents. They are **not** in this repository; ask Marketing for access.

## Sources

| Code | Document | Date |
|---|---|---|
| POS | Positioning strategy (`Stratégie_positionnement CleanHorizon`) | 1 October 2026 |
| Q4 | Clean Horizon General Presentation | Q4 2026 |
| Q3 | Clean Horizon General Presentation | Q3 2026 |
| PFC | Price forecast & COSMOS deck | — |
| SI | Storage Index deck | Covers up to Q2 2026 |
| VID | COSMOS commercial video (`COSMOS_commercial_FINAL_10_2026.mp4`), read from its burned-in subtitles | October 2026 |
| SITE | Current cleanhorizon.com: `/solutions/` page and the four challenges | Screenshots supplied by Marketing, October 2026 |
| HOME | Home page dossier of the new site (form, story cards, navigation, assets) | October 2026 |

## Block by block

| Block | Content | Sources |
|---|---|---|
| 1 Hero | Promise, subtitle, proof points | Q4 ("Reliable price forecasts and proprietary tools to reduce uncertainty"); Q3 ("Q&As and insights behind every data point", three scenarios) |
| 2 Proof band | "18 countries", "Since 2009", logos | Q4 (references "Data & tools + Economic"); SaarLB logo supplied by Marketing on 14 October 2026 |
| 3 Challenges | Four challenges and answers | SITE (the four challenges); intro from POS |
| 4 Three tools | Price Forecasts, COSMOS, Storage Index cards | SITE `/solutions/`; PFC slides 12, 14, 15, 24, 27–30, 32–44; SI slides 3, 5, 10, 28; VID (COSMOS markets, revenue forecasts by market) |
| 5 Diagram | Three steps, battery with six revenue streams | PFC ("How does COSMOS work?"); SI slide 5; VID (revenue-stack order and colours: mFRR, aFRR, FCR, Intraday, Day-Ahead, Capacity market) |
| 6 Method proof | Backtest bars; range chart | PFC (backtest France 2025: 270 and 267 vs 305 k€/MW/yr); SI (Germany Q2 2026: index 271, real assets 211–293, average 255 k€/MW/yr) |
| 7 Relay to advisory | Three options, Kallista quote | POS (mission); PFC (pricing); Q4 (Kallista case, list of expertises) |
| 8 Customer stories | Kallista; Hertz I & II | Q4 references and Kallista case; story cards from HOME |
| 9 Coverage | 18 countries, map, list | Q4 (18 countries for price forecasts); VID (18 countries for COSMOS). Map drawn from that list |
| 10 Subscription | Four steps, confidentiality box | PFC (Pricing, COSMOS SaaS offering) |
| 11 FAQ | Seven questions | Same sources as blocks 4, 6 and 8 |
| 12 Contact | Form | HOME form, plus "Data subscription" preset and "Markets of interest" (the 18 countries) |

## Known conflicts between sources
Each is tracked in `docs/08` (items A1 to A5): coverage 14–16 vs 18 countries; COSMOS 18 vs 26 countries; Storage Index 10 vs 15; "86%" vs 87–88% on the same slide; Enspired data without consent.

## What is deliberately not on the page
- CHESS.
- Any coverage figure other than "18 countries".
- The COSMOS video (reserved for the COSMOS page).
- The "Projects where…" references table.
- Any percentage of accuracy.
