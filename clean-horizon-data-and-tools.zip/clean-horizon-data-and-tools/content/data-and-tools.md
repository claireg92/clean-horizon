# Data & Tools — page copy (readable version)

> Generated from `content/data-and-tools.json`, which is the source. Edit the JSON, not this file. Square brackets = missing fact, never shipped.

**URL** `/solutions/data-and-tools` · **Title** Electricity Price Forecasts & Revenue Data | Clean Horizon · **Meta** Electricity price forecasts in 18 countries, COSMOS revenue simulation and the monthly Storage Index, for storage and hybrid projects.

## 1 · Hero
*DATA & TOOLS · SUBSCRIPTION*

# Electricity price forecasts, revenue simulation and storage benchmarks

Reliable price forecasts and proprietary tools to reduce uncertainty. Price forecasts in 18 countries, COSMOS to simulate revenues on every market, and the monthly Storage Index.

[Talk to a data expert →](#contact) · [See the latest Storage Index →](/solutions/data-and-tools/storage-index)

Our own models · Three price scenarios per country · Q&As and insights behind every data point

Visual: Illustrative example. Replace with a screenshot of the Clean Horizon Platform.

## 2 · Proof band
**Among the developers, IPPs and lenders we work with**

18 countries (with our own price forecasts) · Since 2009 (storage only)

Logo marquee (one line, alternating): Kallista Energy, EBRD, Enertrag, Nordic Investment Bank, TotalEnergies, KBC, EDF Renewables, DNB, European Energy, UniCredit, Alight, Banque des Territoires, R.Power Renewables, BNP Paribas, Enlight, SaarLB – Landesbank Saar, Econergy, Renalfa.

Missing: Crédit Agricole (lender on the Enertrag project): logo to supply

## 3 · Your challenges
A project is financed on assumptions that cannot be measured yet, only tested.

- **Developers** — You need to build a business case, but you don’t know which price assumptions to use or how reliable they are.  
  → Three price scenarios per country, and an assumption book listing every source. [Price Forecasts →](#tools)
- **IPPs and utilities** — You need to compare revenue scenarios before committing to a project size or configuration, without commissioning a full study.  
  → COSMOS: sizing, sensitivity analyses, cash flows, NPV and IRR. [COSMOS →](#tools)
- **Investors and lenders** — You need to benchmark the financial performance of an operational asset against market conditions.  
  → The Storage Index, or a Premium Index built on your asset’s configuration. [Storage Index →](#tools)
- **Battery suppliers** — You want to model the revenue potential of a battery across multiple markets, without the tools or the data to do it properly.  
  → Price forecasts and COSMOS in 18 countries. [COSMOS →](#tools)

Q&As and insights behind every data point.

## 4 · Three tools, from price forecast to revenue benchmark
[Our methodologies →](/resources/methodologies)

### Price Forecasts
*01 · PRICE FORECASTS* — **Electricity and ancillary services price forecasts for building a reliable business model**

Three electricity mix scenarios (low, central, high) per country. Forecasts for day-ahead and intraday markets, FCR, aFRR, mFRR and capacity markets where relevant, at each market’s granularity. Each report includes business cases for a 50 MW reference storage project at 1h, 2h, 3h and 4h.

- **Battery deployment modelled.** We forecast how much storage will be built and its effect on ancillary services, day-ahead and intraday prices.
- **An assumption book** listing the sources and assumptions of each scenario.
- **Q&As and insights** behind every data point.

*Option:* business models tailored to your projects.

[Explore Price Forecasts →](/solutions/data-and-tools/price-forecast) · [How we forecast prices →](/resources/methodologies#price-forecasts)

### COSMOS
*02 · SIMULATION* — **The tool for simulating energy storage revenue stacks**

COSMOS (Clean Horizon Optimal Simulation of Market Operations for Storage) forecasts the revenues of a stand-alone battery, or one co-located with PV or wind, on each market. It finds the optimal sizing, then turns that design into cash flows, NPV and IRR.

Markets: Day-ahead · Intraday · FCR · aFRR · mFRR · Capacity market

- **Sensitivity analysis built in:** low, central, high.
- **Every dispatch decision optimised:** when to charge, when to discharge, just like a well-informed trader.
- **No modelling skills needed.** Describe your project in a few guided steps, right in your browser. Nothing to install, and our experts help you read the results.

*Coverage:* built on local market rules, in 18 countries so far, with more to come.

[Ask for a demo →](#contact) · [Explore COSMOS →](/solutions/data-and-tools/cosmos) · [How COSMOS works →](/resources/methodologies#cosmos)

### Storage Index
*03 · BENCHMARK* — **Monthly revenue benchmarks for battery storage**

The annualised revenue of a 1h, 2h or 4h battery, calculated every month with COSMOS on historical market data. Free, and also published by Nord Pool.

- `FREE` **Storage Index.** One monthly figure per market and duration.
- `NORD POOL` **Granular Storage Index.** One revenue data point per day, by revenue stream.
- `YOUR ASSET` **Premium Index.** Your asset’s own configuration, daily revenues in Excel.

[See all indexes →](/solutions/data-and-tools/storage-index) · [How the index is calculated →](/resources/methodologies#storage-index)

## 5 · One battery, many markets. What will it earn?
Every market pays differently. COSMOS forecasts your project’s revenues on each of them, on Clean Horizon’s price forecasts, then turns them into a business case.

1. **WHAT GOES IN** — Our price forecasts (Low, central and high scenarios, in 18 countries) + Your project (A stand-alone battery, or one co-located with PV or wind, and its grid connection)
2. **COSMOS SIMULATES** — Every charge and discharge decision, day by day, just like a well-informed trader. Built on each country’s market rules.
3. **WHAT COMES OUT** — A revenue forecast, market by market: mFRR, aFRR, FCR, Intraday, Day-Ahead, Capacity market. Then: Cash flows · NPV · IRR, Optimal sizing

Every month, the same COSMOS runs on past market prices to publish the Storage Index. [How COSMOS works →](/resources/methodologies#cosmos)

## 6 · We test our models against what the market paid
[Read our methodologies →](/resources/methodologies#backtests)

- *FORECAST VS ACTUAL · FRANCE · 2-HOUR BATTERY* — Our second-half 2024 forecasts put the net revenues of a 2-hour battery in France at €270k/MW/year for January to April 2025. Actual revenues were €305k/MW/year. The forecast was conservative, about 11% below.
- *INDEX VS REAL ASSETS · GERMANY · Q2 2026* — In the second quarter of 2026, our 2-hour Storage Index for Germany averaged €271k/MW/year. Real assets managed by [Enspired] averaged €255k/MW/year, between €211k and €293k. **Blocker:** Publication requires Enspired's written consent; otherwise remove this proof.

Past results do not guarantee future revenues. Values in €/MW/year.

## 7 · When a decision has to be defended, the same team takes over
*FROM DATA TO ADVISORY* — Subscriptions come first. Advisory is added where a decision has to be defended in front of someone: the lender, the supplier, the counterparty.

- **01 We run COSMOS for you** A tailored business case for a standalone or hybrid project, or up to 12 simulations to find its optimal configuration.
- **02 We present the method to your lenders and shareholders** “Rather than explaining it again ourselves, we called on Clean Horizon’s experts to present their whole method and the different markets to both our shareholders and our lending banks.” — David Saint-André, New Markets Director, Kallista Energy
- **03 We take the project further** Revenue stack analysis, Commercial due diligence, Supplier selection and contract negotiation, Technical due diligence

[Explore Economic Advisory →](/solutions/economic-advisory) · [Explore Technical Advisory →](/solutions/technical-advisory)

## 8 · Business cases that went to the bank
[View all customer stories →](/customer-stories) — Listing page is V2 in the sitemap: hide this link until it exists.

- **1h, 2h or 4h? How Kallista sized a 120 MW battery its banks would accept** (Data & Tools, Economic, Technical) — Price forecasts, COSMOS simulations and a turnkey tender, from the permit to the lenders. · 120 MW 240 MWh, Saleux (France) · 2h 2 cycles a day, chosen with COSMOS → `/customer-stories/kallista-energy-saleux-120-mw-battery`
- **One business case, three lenders: 200 MW of batteries in Estonia** (Data & Tools, Economic, Estonia) — Price forecasts, business cases and expert sessions for EBRD, the Nordic Investment Bank and Edmond de Rothschild. · 200 MW 400 MWh, Hertz I & II · 3 lenders EBRD, NIB, Edmond de Rothschild → `/customer-stories/[hertz slug to confirm]`

## 9 · Which markets we cover
1. **Price Forecasts** — 18 countries, shown on the map.
2. **COSMOS** — Built on local market rules, in 18 countries so far, with more to come.
3. **Storage Index** — Published every month for the markets listed on the Storage Index page.

Map badge: 18 countries · Countries: Belgium, Bulgaria, Denmark, Estonia, Finland, France, Germany, Great Britain, Italy, Latvia, Lithuania, Luxembourg, Netherlands, Poland, Portugal, Romania, Spain, Sweden

Known issue: Map shows 17 countries: Luxembourg is not visible at this scale.

[Ask about a market →](#contact)

## 10 · How a subscription works
01. **Talk to a data expert** — Tell us your markets and the decision ahead.
02. **Choose your geographies** — Subscriptions are annual, per geography.
03. **Get onboarded** — A detailed user manual, a case study done with our experts, and help with your first simulation.
04. **Work on the Clean Horizon Platform** — Your reports, dynamic graphs and simulations in one place, with our experts on hand for any question.

**Confidentiality** — Manage user access and erase past simulations. All simulations are automatically erased after 30 days to prevent unwanted data leaks. [Security and confidentiality at Clean Horizon →](/about/security-and-expertise) [ISO 27001 badge, if the certification covers the platform]

[Request pricing →](#contact)

## 11 · Frequently asked questions
Method in detail on our methodologies page.

**How does Clean Horizon forecast electricity prices?**  
We build three scenarios (low, central, high) per country from national publications, industry reports and our own view. AI models trained on historical hourly data turn them into day-ahead and ancillary services prices. A separate model estimates battery deployment and its effect on prices. Details on our methodology page.

**Which markets and revenue streams are covered?**  
Price forecasts cover 18 countries: day-ahead and intraday markets, FCR, aFRR and mFRR, and capacity markets where they exist.

**Which markets can COSMOS simulate?**  
COSMOS runs the same revenue stack for a stand-alone battery, or one co-located with PV or wind: day-ahead, intraday, FCR, aFRR, mFRR and capacity market. It is built on local market rules, in 18 countries so far.

**How close are your forecasts to actual revenues?**  
For a 2-hour battery in France, our second-half 2024 forecasts gave €270k/MW/year for January to April 2025, against €305k/MW/year of actual revenues. Our backtests are described on our methodology page.

**What is the difference between the Storage Index, the Granular Storage Index and the Premium Index?**  
The Storage Index is free: one monthly revenue figure per market for a 1h, 2h and 4h battery. The Granular Storage Index, on Nord Pool, gives one revenue data point per day, by revenue stream. The Premium Index is calculated on your own asset’s configuration.

**Do I need to install COSMOS?**  
No. COSMOS runs on the Clean Horizon Platform. Clean Horizon can also run the simulations for you.

**Can I show your forecasts to a lender?**  
Our price forecasts and business cases have been used for bank financings in France, Belgium, Sweden and Lithuania, among others. We can also present the method to your lenders and shareholders.

## 12 · Which markets do you need to model?
Tell us your markets and the decision ahead. A data expert will come back to you.

- Name (text)
- Business email (email)
- Company (text)
- Role (select): Developer, IPP / utility, Investor / fund, Lender, Equipment supplier, Other
- What is your project? (select): Market entry, Business case, Feasibility and design, Supplier tender, Due diligence, Data subscription, Other — default **Data subscription**
- Markets of interest (multiselect): Belgium, Bulgaria, Denmark, Estonia, Finland, France, Germany, Great Britain, Italy, Latvia, Lithuania, Luxembourg, Netherlands, Poland, Portugal, Romania, Spain, Sweden, Other — NEW field
- Message (optional) (textarea)

Button: **Talk to a data expert** · [Response time to validate with the sales team.]

Pending option: Second button 'Get a sample forecast report' (name, business email, company) — only if the sample exists. Not in the design.
