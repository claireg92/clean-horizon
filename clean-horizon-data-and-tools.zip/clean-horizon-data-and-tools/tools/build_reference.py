"""Build web/reference/data-and-tools.html from the two design artboards.

- strips the design-tool runtime (helmet, sc-for, sc-if, data-dc-script)
- expands the logo marquee from content/data-and-tools.json
- turns the FAQ accordion into native <details>/<summary>
- rewrites /_blob/<id> asset urls to the repo's assets/ folder
- adds <head> SEO tags and JSON-LD built from the content file
"""
import json, re, sys, html
from pathlib import Path

H = Path(sys.argv[1])            # handoff root
D = H / 'design' / 'data-and-tools'
C = json.loads((H / 'content' / 'data-and-tools.json').read_text())

BLOB = {
    '1ba2c6e0879ce2f91c04235439a94d25': 'brand/clean-horizon-logo.png',
    '4b7922674d085b579caced72d2256a97': 'brand/watermark-shape.svg',
    '77f2a10e1a2410c6b15a50667e6d518e': 'brand/iso-27001-badge.png',
    '98c40f1cd3ed2ce8423946f71eb5fb46': 'images/coverage-map-price-forecasts.svg',
    '278b09d004467b1edac27f88ff93257b': 'logos/kallista-energy.png',
    'f49a86797e51d712bb8a2a66758efb01': 'logos/ebrd.png',
    'a46c09b01d5e2148567c667a50888b77': 'logos/nordic-investment-bank.jpg',
    '177c790f6d7a080fee7dc3c411bfa7dd': 'logos/kbc.png',
    '6c29153545d5cc06cc732eba424dabb8': 'logos/dnb.webp',
    '8ee354eb2be160cd7fd471ff6882fb06': 'logos/unicredit.webp',
    'bd006675f7de8691e02d6a110167aa95': 'logos/bnp-paribas.png',
    'e97b5f5dd8a10fe68a293768af58e045': 'logos/banque-des-territoires.webp',
    '2db25376e715ac734a1f65976e947ef2': 'logos/saarlb.svg',
    '1e68a5bf76d1e4eebc27e12a01fc6a37': 'logos/totalenergies.svg',
    'd006b76c8ebdff614e2d975e8da1b50a': 'logos/edf-renewables.webp',
    '3edb11ef886e20a60a0f2525a7da33ba': 'logos/enertrag.png',
    '0533871a7ca5086c93e8e60f91d1ae4f': 'logos/european-energy.webp',
    '3c1b5aae0228e47d17cdf0b94fd35b41': 'logos/alight.png',
    '48cda54484b09c41b657694fdc637d19': 'logos/rpower-renewables.webp',
    '16b07ccfb994933a344cce22fb282352': 'logos/enlight.webp',
    'd120a9d5914c570a31d977339851d094': 'logos/econergy.png',
    '62dec0bbd1b4e122b023e1faaa68b3ef': 'logos/renalfa.png',
}
REL = '../../assets/'


def split(path):
    src = path.read_text()
    m = re.search(r'<x-dc>(.*)</x-dc>', src, re.S)
    body = m.group(1)
    styles = re.findall(r'<style>(.*?)</style>', body, re.S)
    body = re.sub(r'<helmet>.*?</helmet>', '', body, flags=re.S)
    return body.strip(), '\n'.join(styles)


def blobs(s):
    def rep(m):
        bid = m.group(1)
        if bid not in BLOB:
            raise SystemExit(f'unknown blob {bid}')
        return REL + BLOB[bid]
    return re.sub(r'/_blob/([0-9a-f]{32})', rep, s)


main, st1 = split(D / 'Main.dc.html')
part2, st2 = split(D / 'Part2.dc.html')

# 1. marquee: expand the sc-for with the content list (twice, second copy hidden from AT)
m = re.search(r'<sc-for list="\{\{logos\}\}"[^>]*>\s*(.*?)\s*</sc-for>', main, re.S)
tpl = m.group(1)
items = []
for copy in (0, 1):
    for lg in C['proofBand']['marquee']['logos']:
        alt = '' if copy else html.escape(lg['name'])
        it = tpl.replace('{{lg.src}}', REL + lg['file'].replace('assets/', '')).replace('{{lg.alt}}', alt)
        if copy:
            it = it.replace('<span ', '<span aria-hidden="true" ', 1)
        items.append(it)
main = main[:m.start()] + '\n'.join(items) + main[m.end():]

# 2. FAQ: button + sc-if  ->  details/summary
faq_re = re.compile(
    r'<div style="border-bottom: 1px solid #E6E9EE;">\s*'
    r'<button type="button" aria-expanded="\{\{e(\d)\}\}" onClick="\{\{t\d\}\}" style="([^"]*)">'
    r'<span>(.*?)</span><span aria-hidden="true" style="([^"]*)">\{\{i\d\}\}</span></button>\s*'
    r'<sc-if value="\{\{o\d\}\}"[^>]*>(.*?)</sc-if>\s*</div>', re.S)

def faq(m):
    n, bstyle, q, istyle, ans = m.groups()
    bstyle = bstyle.replace('width: 100%; background: transparent; border: 0; ', '') + ' cursor: pointer; list-style: none;'
    op = ' open' if n == '0' else ''
    return (f'<details class="dt-faq-item"{op} style="border-bottom: 1px solid #E6E9EE;">'
            f'<summary style="{bstyle}"><span>{q}</span><span class="dt-faq-ico" aria-hidden="true" style="{istyle}">+</span></summary>'
            f'{ans}</details>')

part2, nfaq = faq_re.subn(faq, part2)
assert nfaq == len(C['faq']['items']), nfaq

body = blobs(main + '\n' + part2)
assert '{{' not in body and '<sc-' not in body, re.findall(r'.{40}(?:\{\{|<sc-).{40}', body)[:3]

# Resolve the design's href="#" placeholders to the real targets listed in the JSON.
# Links whose target is not decided yet (header nav, Login, Market Insights, Events,
# Legal notice, Privacy) keep href="#" and get data-href-todo.
def _norm(t):
    t = html.unescape(re.sub(r'<[^>]+>', ' ', t))
    return re.sub(r'\s+', ' ', t).replace('→', '').strip()
LINKS = {}
def _collect(o):
    if isinstance(o, dict):
        if 'href' in o and '[' not in o['href']:
            for k in ('label', 'title', 'name'):
                if isinstance(o.get(k), str):
                    LINKS.setdefault(_norm(o[k]), o['href'])
        for v in o.values(): _collect(v)
    elif isinstance(o, list):
        for v in o: _collect(v)
_collect(C)
LINKS.update({
    'Storage Index page': '/solutions/data-and-tools/storage-index',
    'methodologies page': '/resources/methodologies',
    'Storage Index': '/solutions/data-and-tools/storage-index',
    'Methodologies': '/resources/methodologies',
    'Customer stories': '/customer-stories',
})
STORY = {_norm(s['title']): s['href'] for s in C['customerStories']['cards']}
def _link(m):
    pre, post, inner = m.group(1), m.group(2), m.group(3)
    t = _norm(inner)
    href = LINKS.get(t)
    if href is None and 'clean-horizon-logo' in inner:
        href = '/'
    if href is None:
        href = next((h for title, h in STORY.items() if title in t), None)
        if href and '[' in href:
            href = None
    if href is None:
        return f'<a{pre}href="#" data-href-todo{post}>{inner}</a>'
    return f'<a{pre}href="{href}"{post}>{inner}</a>'
body = re.sub(r'<a([^>]*?)href="#"([^>]*)>(.*?)</a>', _link, body, flags=re.S)

css = blobs(st1 + '\n' + st2)
css += """
.dt-faq-item summary::-webkit-details-marker{display:none}
.dt-faq-item[open] .dt-faq-ico{transform:rotate(45deg)}
.dt-faq-ico{transition:transform .2s ease}
html{scroll-behavior:smooth}
@media (prefers-reduced-motion: reduce){html{scroll-behavior:auto}}
"""

base = 'https://www.cleanhorizon.com'
seo = C['seo']
jsonld = [
    {"@context": "https://schema.org", "@type": "Service",
     "name": "Data & Tools: electricity price forecasts, COSMOS revenue simulation and Storage Index",
     "description": seo['metaDescription'],
     "provider": {"@type": "Organization", "name": "Clean Horizon", "url": base},
     "areaServed": C['coverage']['countries'],
     "url": base + seo['canonical']},
    {"@context": "https://schema.org", "@type": "ItemList",
     "itemListElement": [
         {"@type": "ListItem", "position": i + 1, "name": c['name'], "url": base + c['primaryCta']['href'] if c['primaryCta']['href'].startswith('/') else base + c['secondaryCta']['href']}
         for i, c in enumerate(C['tools']['cards'])]},
    {"@context": "https://schema.org", "@type": "BreadcrumbList",
     "itemListElement": [{"@type": "ListItem", "position": i + 1, "name": b['label'], "item": base + b['href']} for i, b in enumerate(seo['breadcrumb'])]},
    {"@context": "https://schema.org", "@type": "FAQPage",
     "mainEntity": [{"@type": "Question", "name": f['q'], "acceptedAnswer": {"@type": "Answer", "text": f['a']}} for f in C['faq']['items']]},
]

page = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(seo['title'])}</title>
<meta name="description" content="{html.escape(seo['metaDescription'])}">
<link rel="canonical" href="{base}{seo['canonical']}">
<!-- REFERENCE BUILD: visual and behavioural reference for developers, generated from design/data-and-tools/*.dc.html.
     Not production code: inline styles mirror the design file one-to-one. Rebuild the page with the site's components. -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Carlito:wght@400;700&amp;display=swap">
<style>
{css}
</style>
{''.join(f'<script type="application/ld+json">{json.dumps(j, ensure_ascii=False)}</script>' + chr(10) for j in jsonld)}</head>
<body>
{body}
</body>
</html>
"""
out = H / 'web' / 'reference' / 'data-and-tools.html'
out.write_text(page)
print('written', out, len(page), 'faq', nfaq, 'logos', len(items))
