import json, sys
from pathlib import Path
H = Path(sys.argv[1]); C = json.loads((H/'content/data-and-tools.json').read_text())
o = []; w = o.append
def cta(c): return f"[{c['label']}]({c['href']})"
w("# Data & Tools — page copy (readable version)\n")
w("> Generated from `content/data-and-tools.json`, which is the source. Edit the JSON, not this file. Square brackets = missing fact, never shipped.\n")
s=C['seo']; w(f"**URL** `{s['canonical']}` · **Title** {s['title']} · **Meta** {s['metaDescription']}\n")
h=C['hero']; w("## 1 · Hero"); w(f"*{h['eyebrow']}*\n\n# {h['h1']}\n\n{h['subtitle']}\n\n{cta(h['primaryCta'])} · {cta(h['secondaryCta'])}\n\n" + " · ".join(h['proofPoints']) + f"\n\nVisual: {h['visual']['caption']}\n")
p=C['proofBand']; w("## 2 · Proof band"); w(f"**{p['title']}**\n\n" + " · ".join(f"{x['value']} ({x['label']})" for x in p['stats']) + "\n\nLogo marquee (one line, alternating): " + ", ".join(l['name'] for l in p['marquee']['logos']) + f".\n\nMissing: {'; '.join(p['marquee']['missing'])}\n")
c=C['challenges']; w(f"## 3 · {c['title']}"); w(c['intro']+"\n")
for i in c['items']: w(f"- **{i['audience']}** — {i['challenge']}  \n  → {i['answer']} {cta(i['link'])}")
w(f"\n{c['closing']}\n")
t=C['tools']; w(f"## 4 · {t['title']}"); w(cta(t['link'])+"\n")
for k in t['cards']:
    w(f"### {k['name']}\n*{k['label']}* — **{k['tagline']}**\n\n{k['body']}\n")
    if k.get('markets'): w("Markets: " + " · ".join(k['markets'])+"\n")
    for pt in k.get('points',[]): w(f"- **{pt['lead']}** {pt['text']}")
    for lv in k.get('levels',[]): w(f"- `{lv['badge']}` **{lv['name']}** {lv['text']}")
    if k.get('note'): w(f"\n*{k['note']['lead']}* {k['note']['text']}")
    links=[cta(k['primaryCta'])]+([cta(k['secondaryCta'])] if k.get('secondaryCta') else [])+[cta(k['secondaryLink'])]
    w("\n"+" · ".join(links)+"\n")
e=C['engine']; w(f"## 5 · {e['title']}"); w(e['intro']+"\n")
st=e['steps']
w(f"1. **{st[0]['label']}** — " + " + ".join(f"{x['title']} ({x['text']})" for x in st[0]['items']))
w(f"2. **{st[1]['label']}** — {st[1]['text']} {st[1]['footnote']}")
w(f"3. **{st[2]['label']}** — {st[2]['title']}: " + ", ".join(st[2]['battery']) + ". Then: " + ", ".join(st[2]['then']))
w(f"\n{e['footer']['text']} {cta(e['footer']['link'])}\n")
m=C['methodProof']; w(f"## 6 · {m['title']}"); w(cta(m['link'])+"\n")
for pr in m['proofs']: w(f"- *{pr['label']}* — {pr['caption']}" + (f" **Blocker:** {pr['blocker']}" if pr.get('blocker') else ""))
w(f"\n{m['disclaimer']}\n")
r=C['advisoryRelay']; w(f"## 7 · {r['title']}"); w(f"*{r['eyebrow']}* — {r['intro']}\n")
for op in r['options']:
    line=f"- **{op['n']} {op['title']}** "
    if op.get('text'): line+=op['text']
    if op.get('quote'): line+=f"“{op['quote']['text']}” — {op['quote']['author']}, {op['quote']['role']}"
    if op.get('bullets'): line+=", ".join(op['bullets'])
    w(line)
w("\n"+" · ".join(cta(x) for x in r['ctas'])+"\n")
cs=C['customerStories']; w(f"## 8 · {cs['title']}"); w(f"{cta(cs['link'])} — {cs['link']['note']}\n")
for k in cs['cards']: w(f"- **{k['title']}** ({', '.join(k['tags'])}) — {k['text']} · " + " · ".join(f"{x['value']} {x['label']}" for x in k['stats']) + f" → `{k['href']}`")
cv=C['coverage']; w(f"\n## 9 · {cv['title']}")
for i in cv['items']: w(f"{i['n']}. **{i['title']}** — {i['text']}")
w(f"\nMap badge: {cv['map']['badge']} · Countries: " + ", ".join(cv['countries']) + f"\n\nKnown issue: {cv['map']['knownIssue']}\n\n{cta(cv['cta'])}\n")
sb=C['subscription']; w(f"## 10 · {sb['title']}")
for x in sb['steps']: w(f"{x['n']}. **{x['title']}** — {x['text']}")
cf=sb['confidentiality']; w(f"\n**{cf['title']}** — {cf['text']} {cta(cf['link'])} {cf['badge']}\n\n{cta(sb['cta'])}\n")
f=C['faq']; w(f"## 11 · {f['title']}"); w(f['intro']+"\n")
for x in f['items']: w(f"**{x['q']}**  \n{x['a']}\n")
ct=C['contact']; w(f"## 12 · {ct['title']}"); w(ct['text']+"\n")
for fl in ct['form']['fields']: w(f"- {fl['label']} ({fl['type']})" + (f": {', '.join(fl['options'])}" if fl.get('options') else "") + (f" — default **{fl['default']}**" if fl.get('default') else "") + (" — NEW field" if fl.get('new') else ""))
w(f"\nButton: **{ct['form']['submit']}** · {ct['form']['underButton']}\n\nPending option: {ct['optionPending']}\n")
(H/'content/data-and-tools.md').write_text("\n".join(o))
print('ok', len("\n".join(o)))
