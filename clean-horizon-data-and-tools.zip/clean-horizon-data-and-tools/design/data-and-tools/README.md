# Design source: Data & Tools page

These are the source files of the Claude Design canvas **"Clean Horizon – Data & Tools page"** (private to Clean Horizon; ask Marketing for access: https://claude.ai/artifact/BsXyozqqjcwuTLFfT1JSJ6).

**They are not plain HTML.** They use the design tool's runtime (`<x-dc>`, `<helmet>`, `<sc-for>`, `<sc-if>`, `<dc-import>`) and will not render correctly when opened in a browser. To look at the page, open `web/reference/data-and-tools.html`, which is generated from these files by `tools/build_reference.py`.

| File | Content | Board size on the canvas |
|---|---|---|
| `Main.dc.html` | Header, solutions bar, blocks 1–4 | 1440 wide |
| `Part2.dc.html` | Blocks 5–12 and footer | 1440 wide |
| `MobileMain.dc.html` | Imports `Main` and shows it at 390 px | 390 wide |
| `MobilePart2.dc.html` | Imports `Part2` and shows it at 390 px | 390 wide |
| `canvas.json` | Board positions on the canvas | |

Desktop and mobile share one source: the mobile boards only import the desktop files. All responsive rules sit in the `@container dt (max-width: 760px)` block of each file's `<helmet><style>`.

## Asset map
Images in these files point to `/_blob/<id>`, the design tool's storage. The same files are in this repo:

| Blob id | File |
|---|---|
| `1ba2c6e0879ce2f91c04235439a94d25` | `assets/brand/clean-horizon-logo.png` |
| `4b7922674d085b579caced72d2256a97` | `assets/brand/watermark-shape.svg` |
| `77f2a10e1a2410c6b15a50667e6d518e` | `assets/brand/iso-27001-badge.png` |
| `98c40f1cd3ed2ce8423946f71eb5fb46` | `assets/images/coverage-map-price-forecasts.svg` |
| `278b09d004467b1edac27f88ff93257b` | `assets/logos/kallista-energy.png` |
| `f49a86797e51d712bb8a2a66758efb01` | `assets/logos/ebrd.png` |
| `a46c09b01d5e2148567c667a50888b77` | `assets/logos/nordic-investment-bank.jpg` |
| `177c790f6d7a080fee7dc3c411bfa7dd` | `assets/logos/kbc.png` |
| `6c29153545d5cc06cc732eba424dabb8` | `assets/logos/dnb.webp` |
| `8ee354eb2be160cd7fd471ff6882fb06` | `assets/logos/unicredit.webp` |
| `bd006675f7de8691e02d6a110167aa95` | `assets/logos/bnp-paribas.png` |
| `e97b5f5dd8a10fe68a293768af58e045` | `assets/logos/banque-des-territoires.webp` |
| `2db25376e715ac734a1f65976e947ef2` | `assets/logos/saarlb.svg` |
| `1e68a5bf76d1e4eebc27e12a01fc6a37` | `assets/logos/totalenergies.svg` |
| `d006b76c8ebdff614e2d975e8da1b50a` | `assets/logos/edf-renewables.webp` |
| `3edb11ef886e20a60a0f2525a7da33ba` | `assets/logos/enertrag.png` |
| `0533871a7ca5086c93e8e60f91d1ae4f` | `assets/logos/european-energy.webp` |
| `3c1b5aae0228e47d17cdf0b94fd35b41` | `assets/logos/alight.png` |
| `48cda54484b09c41b657694fdc637d19` | `assets/logos/rpower-renewables.webp` |
| `16b07ccfb994933a344cce22fb282352` | `assets/logos/enlight.webp` |
| `d120a9d5914c570a31d977339851d094` | `assets/logos/econergy.png` |
| `62dec0bbd1b4e122b023e1faaa68b3ef` | `assets/logos/renalfa.png` |

`tools/build_reference.py` uses this map to rewrite the URLs.
