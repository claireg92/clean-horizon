# Home page copy (English)

Generated from `home.json`. Edit `home.json`, not this file. Text in `[square brackets]` is a placeholder (see `docs/05-open-items.md`).

## 1. News banner
NEW · STORAGE INDEX  
**The [Month 2026] Storage Index is out**  
Our monthly revenue benchmark: what storage assets actually earn, market by market.  
[Read the index →](/solutions/data-and-tools/storage-index)

## 3. Hero
_The intelligence company for energy storage investments_

# We go where the data stops.

Price forecasts, revenue benchmarks and simulation software, backed by the economists and engineers who stand behind the result. From market analysis to megawatt-hours.

[Get the latest Storage Index →](/solutions/data-and-tools/storage-index) · [Talk to an expert →](/contact-us)

Storage only, since 2009 · Price forecasts in 18 countries

## 4. Logo marquee
Trusted by the lenders, developers and IPPs behind Europe’s storage projects

## 5. The four decisions that cost the most to get wrong
A storage project is financed on assumptions that cannot be measured yet, only tested. The lender discounts every party’s reading of them, and the project pays for the discount.

- **01 · Market Entry**: Is this market worth entering, and when? Market and regulatory analysis, European market comparison. _Asked by Head of Origination._
- **02 · Project Development**: What will the project earn? Price forecasts, revenue stacking and business cases. _Asked by Developer, Head of Storage._
- **03 · Procurement & Build**: Can it be built the way the model assumes? Feasibility, sizing, design, procurement and contracts. _Asked by Head of Storage._
- **04 · Transactions & Financing**: Will the model and the asset both stand up? Technical and commercial due diligence. _Asked by M&A, lenders._

We answer all four: economics and technical advisory, under one roof.

## 6. From markets to megawatt-hours
A storage project is two things at once: a financial model that has to convince a lender, and an installation that has to perform.

**MARKETS**: Price forecasts; Revenue stack; Business case; Commercial due diligence. _The whole project cycle, covered end to end._
**MEGAWATT-HOURS**: Feasibility and sizing; Layouts and single line diagrams; Supplier tender and contracts; Commissioning and test review

Most companies buy those two things from two different firms, then have to make them agree. We do both. We put our name on reports that go to credit committees, which is what makes the analysis hold when it is challenged.

[Explore Technical Advisory →](/solutions/technical-advisory) · [Talk to a technical expert →](/contact-us)

_Technical advisory is delivered directly in France, Belgium and Germany, and through partners elsewhere. [Coverage to confirm.]_

## 7. Subscriptions carry the analysis. Advisory puts it to work on your project.
[All solutions →](/solutions)

### 01 · Subscription — Data & Tools
**Know what storage earns, in every market, all year.** Price forecasts, revenue benchmarks and simulation software, available continuously, so that every business case rests on the same analysis.
- Price forecasts in 18 countries
- COSMOS, our simulation software
- Storage Index and CHESS

**Where:** price forecasts in 18 countries, Storage Index in 10 markets  
[Explore Data & Tools →](/solutions/data-and-tools)

### 02 · Advisory — Energy Storage Strategy
**Decide where, when and how to enter a storage market.** A strategic view of where storage creates value, and how to position a project in it.
- Market and regulatory analysis
- Comparison of European storage markets
- Market entry and route-to-market strategy, with tailored training

**Where:** every market we cover  
[Explore Energy Storage Strategy →](/solutions/energy-storage-strategy)

### 03 · Advisory — Economic Advisory
**A business case the other side of the table cannot set aside.** Realistic assumptions and defensible business models, with accountability for results, for developers, buyers, sellers and lenders.
- Revenue stack analysis
- Business plan optimisation and sizing
- Commercial due diligence, on a single project or a portfolio

**Where:** every market we cover  
[Explore Economic Advisory →](/solutions/economic-advisory)

### 04 · Advisory — Technical Advisory
**A project that is built the way the model assumes.** Owner’s and lender’s engineering for IPPs, utilities and lenders, from design to commissioning.
- Feasibility and development support
- Supplier selection and contract negotiation
- Technical due diligence, commissioning and auditing

**Where:** France, Belgium, Germany directly; partners elsewhere  
[Explore Technical Advisory →](/solutions/technical-advisory)

Battery and system suppliers: [explore our price forecasts →](/solutions/data-and-tools/price-forecast)

## 8. Customer stories (3 at launch)

### 1. 1h, 2h or 4h? How Kallista sized a 120 MW battery its banks would accept
Tags: Data & Tools, Economic, Technical · Logos: Kallista Energy

Price forecasts, COSMOS simulations and a turnkey tender, from the permit to the lenders.

> “Rather than explaining it again ourselves, we called on Clean Horizon’s experts to present their whole method and the different markets to both our shareholders and our lending banks.”
> — David Saint-André, New Markets Director, Kallista Energy  _(client approval pending)_

**Kallista Energy, Saleux (France)**: 120 MW — 240 MWh battery energy storage system · ≈ €100M — Invested without public subsidy

### 2. What two banks needed to see before financing a 2 GWh portfolio
Tags: Economic advisory, France & Finland · Logos: Rabobank, Santander

Commercial due diligence for Rabobank and Santander CIB.

**NW Storm portfolio**: 2 GWh — 1,000 MW / 2,000 MWh portfolio · 2 banks — Commercial due diligence for Rabobank & Santander CIB

### 3. Buying 240 MW of storage: the due diligence behind the deal
Tags: Technical, Economic, France · Logos: Banque des Territoires

Technical and economic due diligence for the buyer, with Banque des Territoires.

**Cernay-lès-Reims**: 240 MW — 480 MWh battery project · Buy side — Technical & economic due diligence

### 4. One business case, three lenders: 200 MW of batteries in Estonia _(not on the home page at launch)_
Tags: Data & Tools, Economic, Estonia · Logos: EBRD, Nordic Investment Bank, Edmond de Rothschild

Price forecasts, business cases and expert sessions for EBRD, the Nordic Investment Bank and Edmond de Rothschild.

**Hertz I and II**: 200 MW — 400 MWh of batteries · 3 lenders — EBRD, Nordic Investment Bank, Edmond de Rothschild

## 9. Storage Index block
STORAGE INDEX

**The Storage Index: what storage assets actually earn, every month**

Our monthly revenue benchmark for battery storage, covering 10 markets. Use it to check your business case against the market, not against a forecast.

[See the latest Storage Index →](/solutions/data-and-tools/storage-index) · [See what this means for your project →](/contact-us)

LATEST EDITION: [Month 2026] — [Chart of the latest month and key figure, shown in full and without registration.]

## 10. Why developers, investors and lenders choose Clean Horizon

- **Close to you**: An agile team you can talk to, with Q&As and insights behind every data point, adapted to your question.
- **Storage only**: Since 2009, one market only: from Europe’s first grid-scale batteries to today’s multi-hour portfolios. No adjacent business to subsidise.
- **Full cycle**: From market analysis to commissioning: economists and engineers work on the same project from day one.
- **Transparency**: You see how each forecast and index is built. Our analysts explain every data point behind it.

## 11. Coverage — What we cover, and where

1. **Data and forecasts**: Price forecasts in 18 countries · Storage Index in 10 markets
2. **Market and economic advisory**: Europe, with missions in Brazil, the Middle East and South Africa
3. **Technical advisory**: France, Belgium and Germany directly, through partners elsewhere

Legend: All three, delivered directly / Levels 1 and 2

18 countries: Belgium, Bulgaria, Denmark, Estonia, Finland, France, Germany, Great Britain, Italy, Latvia, Lithuania, Luxembourg, Netherlands, Poland, Portugal, Romania, Spain, Sweden. _[The map shows 17: Luxembourg to add.]_

## 12. Our latest publications
[All publications →](/resources/market-insights). Cards: latest Storage Index edition, latest market analysis, latest report or guide.

## 13. Newsletter
**Our weekly energy storage newsletter**

Five stories that moved storage markets this week, plus one we think you should read.

Fields: Name, Business email, Company · Button: Subscribe

## 14. Contact band
- **Since 2009** — Storage only, no adjacent business
- **18 countries** — With our own price forecasts
- **[Scale figure]** — [To supply: e.g. GW of projects advised, projects or clients since 2009]

**Ready to discuss your project?**

Tell us where your project stands. An analyst and an engineer will come back to you with a view on what it can earn, and whether it is built to earn it.

contact@cleanhorizon.com · +33 (0)1 78 76 57 04

Form: Name, Business email, Company; Role (Developer, IPP / utility, Investor / fund, Lender, Equipment supplier, Other); What is your project? (Market entry, Business case, Feasibility and design, Supplier tender, Due diligence, Data subscription, Other); Message (optional). Button: Book a meeting. _We reply within one working day. [To validate with the sales team.]_

## 15. FAQ

**What does Clean Horizon do?**

We are an intelligence company for energy storage investments, working on storage only since 2009. Our subscriptions give continuous access to price and revenue forecasts, simulation software and market benchmarks. Our advisory teams apply them to a single project, on strategy, economics and engineering, and stand behind the result in front of the lender, the supplier and the counterparty.

**Can you advise on both the market and the technical side?**

Yes. Most companies buy the financial model from one firm and the technical design from another, then have to make them agree. We do both, with our economists and our engineers working on the same project, so the revenue model and the technical design are built together. Technical advisory is delivered directly in France, Belgium and Germany, and through partners elsewhere. [Coverage to confirm.]

**Which markets do you cover?**

Our own price forecasts cover 18 countries, and the Storage Index covers 10 markets. Market and economic advisory covers Europe, with missions in Brazil, the Middle East and South Africa. Technical advisory is delivered directly in France, Belgium and Germany, and through partners elsewhere.

**Can your work be used in front of lenders and investment committees?**

That is what it is built for. We act as market advisor and lender’s engineer, and our analysts answer the committee’s questions. Recent mandates include the commercial due diligence of a 2 GWh portfolio for Rabobank and Santander CIB, and price forecasts for the Hertz I and II projects financed by the EBRD and the Nordic Investment Bank.

**What is the Storage Index?**

Our monthly revenue benchmark for battery storage, covering 10 markets, published by our analysts. It lets you check a business case against the market, not against a forecast. [Access conditions to confirm.]

**How do I access your data?**

Through a subscription to our price forecasts, COSMOS, the Storage Index and the CHESS project database, with an analyst behind every data point. [Subscription formats, demo or trial conditions to confirm.]

**What happens after I get in touch?**

Tell us where your project stands in the deal. We tell you which question to answer first, and who on our team answers it. [Response time to commit to.]

## 16. Footer
From markets to megawatt-hours. The intelligence company for energy storage investments.

ISO 27001 badge: Information security management, certified.

Offices: 12 rue Portalis, 75008 Paris, France · 1200 Brickell Ave, Suite 1960, Miami, FL 33131, USA

Social: https://www.linkedin.com/company/clean-horizon · https://www.youtube.com/@cleanhorizonconsulting7389

© 2026 Clean Horizon · Legal notice · Privacy
