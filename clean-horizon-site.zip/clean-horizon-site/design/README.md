# Design source files

These are the source files of the design as exported from the design tool: one `.dc.html` per artboard.

| File | Artboard | Size |
|---|---|---|
| `Main.dc.html` | Home desktop 1/2: banner, hero, logos, four decisions, markets to megawatt-hours, offers | 1440 wide |
| `Desktop2.dc.html` | Home desktop 2/2: customer stories, Storage Index, why Clean Horizon, coverage, publications, newsletter, contact, FAQ, footer | 1440 wide |
| `Menu.dc.html` | Desktop mega menu (Solutions, Resources, About) | 1440 wide |
| `Mobile1.dc.html`, `Mobile2.dc.html`, `Mobile3.dc.html` | Home on mobile, in three parts | 390 wide |
| `MobileMenu.dc.html` | Mobile menu | 390 wide |
| `canvas.json` | Position and size of each artboard on the canvas | |

## How to use them
- **To see the design, open the hosted design link** (in the root README), not these files: they need the design tool's runtime (`support.js`) to render and are not production code.
- **To read exact values** (colours, font sizes, paddings, radii), open any file and read the inline `style` attributes. Everything is in plain inline CSS.
- Images are referenced as `/_blob/<id>`: see `ASSET_MAP.md` for the real file of each.
- `{{ ... }}` markers, `<sc-for>` and `<sc-if>` are the tool's templating (loops and conditions). Ignore them; the content they hold is in `../content/home.json`.
- **Do not copy fixed heights.** Section heights were estimated by hand and were never measured in a browser; build with natural content height.
- Some artboards have a decorative gradient and a faded logo watermark; the watermark file is `../assets/brand/watermark-shape.svg`.
