# Design file assets: `/_blob/<id>` to repository file

The `.dc.html` files reference images as `/_blob/<id>` (a URL that only resolves inside the hosted design). Use this table to find the matching file.

| Blob id | File |
|---|---|
| `6aca36ca5003d3e2f84efd713f707e11` | `assets/images/hero-battery-container.webp` |
| `fba2469ed3288064bf0a756dd4eebc80` | `assets/images/coverage-map-europe.svg` |
| `465aa70f3926be46a4a2517738849ed7` | `assets/brand/watermark-shape.svg` |
| `3693b45ec3302aa3bf07f734d4d01bff` | `assets/brand/clean-horizon-logo.png` |
| `f81428bcc2fce7b8d77e3236f248b423` | `assets/brand/iso-27001-badge.png` |
| `885dfe52cf2d91b7987300e74f5e5dd2` | `assets/logos/lender/abp.png` (ABP) |
| `555bebfa5591965fea3f6c98b2735a22` | `assets/logos/lender/aquila-capital.png` (Aquila Capital) |
| `dffb42d7773c55094f58a450271ea777` | `assets/logos/lender/ardian.webp` (Ardian) |
| `041807fc857c1d224ca5ac5557a21bd1` | `assets/logos/lender/bnp-paribas.png` (BNP Paribas) |
| `c21323e264be78e3ebf9aa3834d4ad5a` | `assets/logos/lender/cic.png` (CIC) |
| `5ec87a93e841a821e730d9d309cf0f7e` | `assets/logos/lender/commerzbank.png` (Commerzbank) |
| `2cf268bc0b2d6d929886be7c6af31a7d` | `assets/logos/lender/credit-agricole.png` (Crédit Agricole) |
| `2e77866114f89e0adad7d9f60a95306f` | `assets/logos/lender/credit-cooperatif.png` (Crédit Coopératif) |
| `150b23f933df262616a3a2d128bf9be5` | `assets/logos/lender/dnb.webp` (DNB) |
| `10cb0c8e365b6b0a4b84f724774f3416` | `assets/logos/lender/ebrd.png` (EBRD) |
| `a21f4f5310fd069011145a2e9dfd9d1c` | `assets/logos/lender/helia-conseil.png` (Hélia Conseil) |
| `cbf421febfba4f773306715d261413db` | `assets/logos/lender/infranity.png` (Infranity) |
| `9194b35d32774a254bb7aba45995a60c` | `assets/logos/lender/infravia.png` (InfraVia) |
| `fd7cff287f475f2c20de1ac77c8eb645` | `assets/logos/lender/kbc.png` (KBC) |
| `2aef42bf8a145f829913b8137036b2b5` | `assets/logos/lender/landesbank-saar.png` (Landesbank Saar) |
| `e9f601a7d7492dbe05a10ef73569220c` | `assets/logos/lender/banque-des-territoires.webp` (Banque des Territoires) |
| `e04ad6f12c4180f4a13606493b271077` | `assets/logos/lender/bpifrance.webp` (Bpifrance) |
| `bd288720ab5e6fc342965a655bb94a8d` | `assets/logos/lender/caisse-depargne.webp` (Caisse d’Epargne) |
| `a4dba633cf3a454a0c3d30c18bff4dd6` | `assets/logos/lender/societe-generale.png` (Société Générale) |
| `2d8b3d96c33b96bd75316ddcfa5bd4a1` | `assets/logos/lender/mirova.png` (Mirova) |
| `b7438ec63c48a7cdfc75d5800f4669f4` | `assets/logos/lender/nature-infrastructure-capital.png` (Nature Infrastructure Capital) |
| `8de801ae24ba18bc4a4ca9c72ada7716` | `assets/logos/lender/nordic-investment-bank.jpg` (Nordic Investment Bank) |
| `6438c3bf6e7e510d4816cd1acccc3e2a` | `assets/logos/lender/nomura.webp` (Nomura) |
| `eb93d11fe3423319ad7f962514703309` | `assets/logos/lender/noy.webp` (NOY) |
| `e0667baf5f59972c775403b796a0e6fd` | `assets/logos/lender/bank-pekao.png` (Bank Pekao) |
| `d9b54fcd5d01bc316fc2ca781d7ac9db` | `assets/logos/lender/rabobank.png` (Rabobank) |
| `f886d9d96bd9c670ac48fa37d9116dc0` | `assets/logos/lender/edmond-de-rothschild.png` (Edmond de Rothschild) |
| `839fbc5b5cce48bf204b73b55bc61921` | `assets/logos/lender/rgreen-invest.png` (RGreen Invest) |
| `e26604535592be2072c7f9416844ac10` | `assets/logos/lender/santander.png` (Santander) |
| `2570e66e9776fcdfb118bbc7f50f85ff` | `assets/logos/lender/tevali-partners.webp` (Tevali Partners) |
| `1d19a2aaa810cfcf1b3657c2053657b9` | `assets/logos/lender/apg.webp` (APG) |
| `a6857002002faca51f7cc56d0758f3db` | `assets/logos/lender/unicredit.webp` (UniCredit) |
| `f0eec180a49475bbc00ffc3ea468bd3c` | `assets/logos/ipp/akuo.png` (Akuo) |
| `16eb4570a58b298bbf93121a2e3d6e37` | `assets/logos/ipp/alight.png` (Alight) |
| `95aaa28dbfe12f530a73d59f12dbfd5d` | `assets/logos/ipp/belectric.jpeg` (Belectric) |
| `8cdfa589ba00f1384bee75142b560523` | `assets/logos/ipp/electrified-thermal-solutions.jpeg` (Electrified Thermal Solutions) |
| `f8bc56ec4ef1491c5e0ba7a1c96668c7` | `assets/logos/ipp/energiequelle.svg` (Energiequelle) |
| `8819b8873c63daf6c0ed22411898926b` | `assets/logos/ipp/enertrag.png` (Enertrag) |
| `1c9648b3fec3d39f59a7040e5e292629` | `assets/logos/ipp/enlight.webp` (Enlight) |
| `f3027da969c29b7c2fa45b08a3877b87` | `assets/logos/ipp/european-energy.webp` (European Energy) |
| `5d047f717ea45b8a606615acdf771718` | `assets/logos/ipp/hyperion-renewables.png` (Hyperion Renewables) |
| `f54f9d72dbc25910c3e836148dc5b813` | `assets/logos/ipp/ib-vogt.png` (ib vogt) |
| `b8900e8a1e4b5a9ccec40807f0fcd241` | `assets/logos/ipp/juwi.webp` (juwi) |
| `8c507ce9aa430ee92eac0914365f69e3` | `assets/logos/ipp/kallista-energy.png` (Kallista Energy) |
| `6a291b883222e31e5831c508137f5627` | `assets/logos/ipp/edf-renewables.webp` (EDF Renewables) |
| `2340c469e200543656bb3044fd49457f` | `assets/logos/ipp/geg.jpg` (GEG) |
| `04b4b50a8f76f71e02c4b04086186535` | `assets/logos/ipp/econergy.png` (Econergy) |
| `468ad1271816b5035860d5cc3df8c458` | `assets/logos/ipp/luxel.jpeg` (Luxel) |
| `ace287fdd03a1d8550467ee2e45f7c08` | `assets/logos/ipp/onesolar.jpeg` (OneSolar) |
| `54d922bb3ce0d256b322c142f50d6f00` | `assets/logos/ipp/r-power-renewables.webp` (R.Power Renewables) |
| `f554baeedf4ec4b6904854d225124c45` | `assets/logos/ipp/renalfa.png` (Renalfa) |
| `d7028602b9f00ebf58afbfbceada11f4` | `assets/logos/ipp/totalenergies.svg` (TotalEnergies) |
| `4f56e1c0f15eda9c675b3a38f6fdc74b` | `assets/logos/ipp/tse.png` (TSE) |
| `d0104fa8c817a9f51bd888de1020b562` | `assets/logos/ipp/valorem.png` (Valorem) |
