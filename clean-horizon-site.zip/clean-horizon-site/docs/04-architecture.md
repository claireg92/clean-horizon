# 04 · Architecture: Astro + Sanity

## Overview
- **Astro**, static output (`output: 'static'`). Pages are generated at build time from Sanity.
- **Sanity Studio** in `studio/`: editors change copy, logos, stories, FAQ and the monthly Storage Index.
- A Sanity **webhook** on publish triggers the host's build hook so the site rebuilds (a few minutes at most for this site's size).
- Images come from the Sanity CDN (`@sanity/image-url`, `auto('format')`, explicit widths).
- No server code is required by the home page. Forms need an endpoint (see Open decisions).

Library versions in the `package.json` files were the latest published when this dossier was prepared (Astro 7, Sanity 6, `@sanity/client` 8). Check changelogs when you install.

## Folder map
```
web/        Astro site (reference components + data loader)
studio/     Sanity Studio (schemas, structure, seed script)
content/    home.json = source of the copy; home.md = readable version
assets/     brand, images, logos (+ manifest)
design/     design source files (see design/README.md)
docs/
```

## Running locally
```bash
# Site on local sample data (no Sanity project needed)
cd web && cp .env.example .env && npm install && npm run dev

# Studio
cd studio && cp .env.example .env   # fill SANITY_STUDIO_PROJECT_ID
npm install && npm run dev

# Fill a dataset from content/home.json (use a throw-away dataset first)
SANITY_PROJECT_ID=xxx SANITY_DATASET=staging SANITY_WRITE_TOKEN=... npm run seed
```
`npm run dev` and `npm run build` first copy `assets/` into `web/public/` (git-ignored) with `scripts/sync-assets.mjs`. **Do not deploy a build made in sample-data mode**: it would serve every logo, approved or not.

Then set `PUBLIC_SANITY_PROJECT_ID` in `web/.env` to switch the site from sample data to Sanity.

What was verified when preparing this dossier: the Astro site builds and renders (sample data mode) and the Studio schemas type-check. **Not verified:** the Studio running in a browser, the seed script against a real project, GROQ queries against real data, and any rendering against the design.

## Content model (Sanity)
| Type | Kind | Notes |
|---|---|---|
| `homePage`, `siteSettings`, `navigation` | singletons | Fixed `_id` equal to the type name; create/duplicate/delete disabled in `sanity.config.ts` |
| `offer` | document | The four solution cards; one CTA each |
| `customerStory` | document | `showOnHome`, `featured`, `order`; quote and figures carry an `approved` flag |
| `clientLogo` | document | `approvedForPublicUse` (default false), `category` (lender/ipp), `showInMarquee`, `marqueeOrder` |
| `storageIndexEdition` | document | One per month; the home card and menu card read the latest |
| `article` | document | Market analysis and reports and guides |
| `faqItem` | document | `showOnHome`, `order` |

Pages other than the home page (solution pages, methodologies, events, team, security, press kit, contact) are **not modelled yet**: they have no design. Model them when their design exists rather than guessing now.

## Rules for editors (encode them as validation where possible)
- Hero H1 is required. Offers: exactly 4. Customer stories on the home: exactly 3. Pillars: exactly 4. Decisions: exactly 4. (Already in the schemas.)
- Text in square brackets is a placeholder: add a Studio validation (or a prebuild check) that blocks publishing a document containing `[`.

## Redirects and SEO (important)
- The monthly **Storage Index page generates most of today's traffic.** Get the exact current URLs (the page and each past monthly edition) from the marketing team and the analytics tool **before** choosing the new URL scheme, and add 301 redirects for every old URL that changes. Losing that page's ranking is the single biggest risk of the migration. [Likely]
- Per page: `<title>`, meta description, canonical, Open Graph image (fields exist in the `seo` object).
- Sitemap and robots: use `@astrojs/sitemap`; block staging with `noindex` and basic auth.
- Performance budget suggestion: hero image priority-loaded, logos lazy-loaded, no client-side JavaScript on the home page except the menu.

## Open decisions for the developer to raise (see also 05)
1. Hosting and build hook (Netlify, Vercel, Cloudflare Pages or other).
2. Form backend and CRM (HubSpot or other). Fields are defined in `content/home.json`.
3. Analytics and consent banner.
4. Draft previews: Sanity Presentation tool or a separate preview build.
5. Whether `/login` links to an existing data platform.
