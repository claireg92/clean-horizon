# 05 · Open items

Everything below must be resolved (or consciously accepted) before launch. "Owner" is a suggestion.

## Placeholders still in the copy (never ship square brackets)
| Placeholder | Where | Owner |
|---|---|---|
| `[Month 2026]` | News banner, Storage Index card, menu card, publications | Content, comes from the latest edition |
| `[Scale figure]` + hint | Contact band (third figure, e.g. GW advised or projects since 2009) | Marketing / sales |
| `[Coverage to confirm.]` | Markets block note, FAQ answer 2 (technical advisory direct in FR/BE/DE, partners elsewhere) | Marketing + technical lead |
| `[The map shows 17: Luxembourg to add.]` | Coverage: the map file shows 17 of the 18 countries | Designer: update `assets/images/coverage-map-europe.svg` |
| `[Access conditions to confirm.]` | FAQ: Storage Index | Marketing |
| `[Subscription formats, demo or trial conditions to confirm.]` | FAQ: data access | Sales |
| `[Response time to commit to.]`, `[To validate with the sales team.]` | FAQ and contact form note ("We reply within one working day") | Sales |
| Publication cards, chart, headline placeholders | Home publications, Storage Index "latest edition" | Content |
| `https://[Welcome to the Jungle URL to supply]` | Careers menu link | Marketing |

## Claims that need a formal sign-off
- **Client logos (54 in `assets/logos`).** Showing a client's logo on a public site normally needs the client's agreement. All logos are `approvedForPublicUse: false` by default. **Keep this repository private until legal/marketing has approved each logo.** Only approved logos should reach production. [Certain: the flag exists; whether approval is needed per client depends on your contracts, which I have not seen.]
- **Kallista quote and the "≈ €100M invested without public subsidy" figure**: client approval pending (flagged `approved: false` by the seed script).
- **ISO 27001 badge.** `assets/brand/iso-27001-badge.png` is a generic image of unknown origin and licence, with the white background removed by hand. Replace it with the certification body's official mark, and confirm the certificate holder and scope before showing "certified". The "[Certificate holder and scope to confirm]" note was removed from the design at the marketing director's request, so confirm this is accurate.
- **Hero photo** (`assets/images/hero-battery-container.webp`): origin and licence not documented. Confirm before launch.
- "Transparency" pillar: confirm that forecast and index methodologies are actually documented publicly (the Methodologies page, V1 lot 3).
- Technical Advisory card says delivery is direct in France, Belgium and Germany and through partners elsewhere. Confirm.

## Design gaps
- No tablet design.
- Not designed: all pages except the home page and the menus (see `01-sitemap.md`).
- Heights in the design file were estimated, not rendered; some artboards may have small blank gaps or clipping. Do not copy pixel heights from `design/`; copy spacing, type and colour.
- Diagram in "Full cycle" is plain HTML/CSS in the design; the skeleton's version is a simplified approximation.

## Technical decisions pending
See `04-architecture.md`: hosting, form backend/CRM, analytics and consent, previews, login destination, URL scheme and redirects.

## Suggested acceptance checklist
- [ ] No `[` in any rendered text
- [ ] 3 customer stories, 4 offers, 4 pillars, 4 decisions, 7 FAQ items
- [ ] 20 logos in the marquee: banks first, then IPPs, all approved
- [ ] Every internal link resolves (no 404 on V2 pages)
- [ ] 301 redirects for all existing indexed URLs, especially the Storage Index
- [ ] Lighthouse: accessibility 95+, performance 90+ on mobile
- [ ] Keyboard-only walk through menu, FAQ and forms
