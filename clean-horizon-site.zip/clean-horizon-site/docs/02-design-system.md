# 02 · Design system (extracted from the design file)

Tokens live in `web/src/styles/tokens.css`. The design was made without a formal design system, so these values were read from the inline styles in `design/*.dc.html`. If the brand team supplies official tokens, they win.

## Colour
| Token | Hex | Use |
|---|---|---|
| `--ch-navy` | `#003F89` | Headings, primary buttons, dark panels |
| `--ch-blue` | `#2B6DB1` | Links, eyebrows, accent panels |
| `--ch-sky` | `#ABC9E1` | Text on navy, light panel |
| `--ch-tint` | `#D3E1EE` | Pale panel |
| `--ch-grey` | `#E6E9EE` | Cards, dividers, pills |
| `--ch-ink` | `#2F3747` | Body text |
| white | `#FFFFFF` | Page background |

Contrast checks that matter: white on `#2B6DB1` is about 5:1 (OK for body text); `--ch-sky` text on navy is fine; never put `--ch-blue` text on `--ch-sky`.

## Type
- **Carlito** (Google Fonts), falling back to Calibri then system sans. Weights 400 and 700 only.
- H1 52 px / 1.05 desktop, 42 px mobile. H2 54 px / 1.04 desktop, 30–32 px mobile. Card titles 24–32 px. Body 16–18 px (desktop up to 20 px in the hero). Eyebrows 12–13 px, bold, letter-spacing 0.12em, uppercase.
- Letter-spacing −0.015em on headings.

## Shape and spacing
- Radius: buttons 14, inner panels 16–20, cards 24 (mobile) or 28 (desktop), large panels 32, pills 999.
- Page gutter 64 px desktop, 24 px mobile. Section spacing 104 px desktop, 48 px mobile.
- Card shadow: `0 12px 32px rgba(0, 63, 137, 0.08)`.
- Touch targets at least 44 px high.

## Recurring patterns
- **Navy band with a watermark.** A navy panel with a faded logo shape (`assets/brand/watermark-shape.svg`) at 30–45% opacity, used for the stats band, the Storage Index block, the Full cycle card and the figures inside customer-story cards.
- **Eyebrow + big title.** Small caps label above each section title.
- **One primary and one secondary button** per block (primary: navy fill; secondary: white with a light border).
- **Marquee** for logos: CSS-only, duplicated list, pauses with `prefers-reduced-motion`.

## Breakpoints
Designed at **1440** and **390**. The skeleton switches layout at **1024 px**. Tablet (768–1023) has no design; stacked layout with larger gutters is the safe default.

## Accessibility baseline
Real `<button>` and `<a>`; labels on every form field; `aria-label` on icon-only controls; visible focus ring; reduced-motion respected; alt text on every meaningful image (decorative watermark images use `alt=""`).
