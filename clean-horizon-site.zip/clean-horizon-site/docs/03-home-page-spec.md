# 03 · Home page spec

Visual source of truth: the `design/` folder (see `design/README.md`) and the design link in the root README. Copy source of truth: `content/home.json` (readable version: `content/home.md`).

**Status column:** `built` = implemented in `web/src/components`; `todo` = to build from the design.

| # | Block | Purpose | Desktop (1440) | Mobile (390) | Sanity source | Status |
|---|---|---|---|---|---|---|
| 1 | News banner | Push the new Storage Index edition | Full-width gradient strip, edition chip + title + link, close button | Same, stacked | `siteSettings.newsBanner` | todo |
| 2 | Header + mega menu | Navigate; "Talk to an expert" | Logo, 4 entries, Login, CTA. Solutions / Resources / About open a mega menu with a featured card (latest Storage Index) | Burger opens a full-screen menu with accordions, Login and CTA fixed at the bottom | `navigation` | todo |
| 3 | Hero | Position and first CTA | Text left, battery photo bleeding right, fading to white | Photo on top, text below, buttons stacked | `homePage.hero` | built |
| 4 | Logo marquee | Social proof | One row, 10 banks then 10 IPPs, slow loop | Same, smaller logos | `clientLogo` (approved and `showInMarquee`) | built |
| 5 | Four decisions | Frame the pain by role | Four columns on a timeline with numbered dots | Vertical list, number left | `homePage.decisions` | todo |
| 6 | From markets to megawatt-hours | Explain "economics + engineering" | Two columns, two CTAs | Stacked columns | `homePage.markets` | todo |
| 7 | Offers | Route to the 4 solutions | Four white cards on a grey band; **one CTA per card** | Stacked | `offer` x4 | todo |
| 8 | Customer stories | Proof | **Three cards side by side**, each: tags, logos, title, summary, (quote on the first), navy figures band, link | Stacked | `customerStory` x3 | built |
| 9 | Storage Index | Keep the main traffic source, push toward contact | Navy panel, two CTAs, "latest edition" card | Same, stacked | `homePage.storageIndex` + `storageIndexEdition` | todo |
| 10 | Why Clean Horizon | Differentiation | Bento: Close to you / Storage only / **Full cycle** (tall, with economists-and-engineers diagram) / Transparency (wide) | Stacked | `homePage.pillars` | built |
| 11 | Coverage | Where we work | Three levels + legend + country list + map | Stacked, map 294 px wide | `homePage.coverage` | todo |
| 12 | Publications | Freshness | Three cards: Storage Index, Market analysis, Reports | Stacked | `storageIndexEdition`, `article` | todo |
| 13 | Newsletter | Low-friction capture | One grey bar: copy + 3 fields + button | Stacked fields | `homePage.newsletter` | todo |
| 14 | Contact band | Convert | Navy panel: three figures, copy, email, phone, form | Stacked | `homePage.contact`, `siteSettings` | todo |
| 15 | FAQ | Objections and SEO | Title left, accordion right, first item open | Single column | `faqItem` | built |
| 16 | Footer | Trust and navigation | Brand, ISO 27001 badge, link columns, offices, social, legal | Stacked | `siteSettings`, `navigation` | todo |

## Interaction notes
- **FAQ:** one item open at a time in the design; the skeleton uses native `<details>` (works without JavaScript, several can be open). Acceptable difference; tell marketing if exclusive-open matters.
- **Mega menu:** Solutions is open by default in the design; keyboard and focus handling are required (Esc closes, Tab moves through links).
- **Marquee and reduced motion:** no animation when `prefers-reduced-motion: reduce`.
- **Forms (blocks 13 and 14):** fields, labels and select options are in `content/home.json`. The submission target (CRM, e-mail, form service) is **not decided**, see `05-open-items.md`.
- **Anchors:** the "Talk to an expert" buttons go to `/contact-us`; on the home page itself they may scroll to block 14.

## Data rules
- A logo appears on the site only if `approvedForPublicUse` is ticked in the Studio (default off).
- A customer quote or a client-sourced figure appears only if its `approved` box is ticked. The skeleton's `getHome()` already filters them.
- Never render text in square brackets. Treat any `[` in a string as a build error (suggestion: a prebuild script that greps the built HTML).

## Home page must-haves (SEO and tracking)
- One `<h1>`: "We go where the data stops."
- `FAQPage` structured data (already in the skeleton's FAQ component).
- Organization structured data on all pages (name, logo, address, social URLs).
- Events to track at least: header CTA, hero CTAs, Storage Index CTAs, contact form submit, newsletter submit, outbound clicks to Welcome to the Jungle and LinkedIn/YouTube. Analytics tool: not decided.
