# 00 · Brief and decisions

## What the site is for
Clean Horizon (energy-storage consultancy and data company, Paris, since 2009) is repositioning as **"the intelligence company for energy storage investments"**. The new site has two jobs:

1. **Generate qualified leads**: it is built as a sales funnel, not a brochure. Every page ends on a path to "Talk to an expert" or to the Storage Index.
2. **Prove expertise**: customer stories, the monthly Storage Index, methodologies and market insights.

Current traffic: about **2,000 visitors a month**, mostly on the **monthly Storage Index page**. That page must survive the migration (see `04-architecture.md`, Redirects and SEO).

## Audiences
| Audience | What they decide |
|---|---|
| Project developers | Pre-permit to ready-to-build; they sell the project to an IPP |
| IPPs | Buy, build and operate |
| Investors (funds) | Finance and buy |
| Battery and system suppliers | Price forecasts; can be integrated in technical studies |

Personas: Head of Storage, M&A, Head of Origination (35–40), Director of New Markets, Business Development, Finance.

## Offer structure (what the home page sells)
- **Subscription:** Data & Tools (price forecasts in 18 countries, COSMOS simulation software, Storage Index in 10 markets, CHESS project database)
- **Advisory:** Energy Storage Strategy, Economic Advisory, Technical Advisory

## Decisions already taken (do not reopen without the marketing director)
- Home H1 is **"We go where the data stops."**
- Always **"18 countries"** (never "30 geographies"). Storage Index covers **10 markets**.
- **No lender count** anywhere. **No audience-routing block** on the home page. **No independence claim** anywhere.
- Economists and engineers are **distinct teams**: write "under one roof" or "on the same project", never "same team".
- **No form on the Storage Index page for now.**
- Header order: **Solutions, Customer stories, Resources, About**, then Login and "Talk to an expert". V2 pages (Security and expertise, Press & Media Kit) are in the menu design but must stay hidden until their pages exist.
- **One CTA per offer card** in the "Subscriptions carry the analysis…" section.
- **One single logo marquee**: 10 banks first, then 10 IPPs.
- **Customer stories: exactly three at launch**, shown as three full cards side by side on desktop (no carousel, no cut-off card), stacked on mobile.
- Restart from zero visually (previous agency work is discarded).

## Tone of the copy
Plain, specific, confident; no superlatives, no invented statistics. Where a fact is missing the design shows a placeholder in square brackets, e.g. `[Scale figure]`. **Square-bracket text must never reach production.** The full list is in `05-open-items.md`.

## Language
English only at launch. Nothing in the content model blocks adding French later (use Sanity document-level i18n or a plugin; not implemented).
