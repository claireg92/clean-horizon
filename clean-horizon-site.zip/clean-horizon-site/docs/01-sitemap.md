# 01 · Sitemap

Source: `Listing des pages Refonte Site.xlsx` (project file). URLs below are **proposed**. They must be reconciled with the current site's URLs before launch (especially the Storage Index page, see `04-architecture.md`).

"Lot" is the delivery batch from the spreadsheet (1 = first). "Design" says what exists today in `design/`.

| Page | Proposed URL | Version | Type | Lot | Sanity content | Design |
|---|---|---|---|---|---|---|
| Homepage | `/` | V1 | Template | 1 | `homePage` (singleton) | Desktop 1440 + mobile 390 |
| Solutions | `/solutions` | V1 | Template | 2 | `offer` (4 docs) | Mega-menu only |
| Data & Tools | `/solutions/data-and-tools` | V1 | Template | 1 | to model | Not designed |
| Economic Advisory | `/solutions/economic-advisory` | V1 | – | – | to model | Not designed |
| Energy Storage Strategy | `/solutions/energy-storage-strategy` | V1 | – | – | to model | Not designed |
| Technical Advisory | `/solutions/technical-advisory` | V1 | – | – | to model | Not designed |
| Price Forecast | `/solutions/data-and-tools/price-forecast` | V1 | Template | 2 | to model | Not designed |
| COSMOS | `/solutions/data-and-tools/cosmos` | V1 | – | – | to model | Not designed |
| Storage Index | `/solutions/data-and-tools/storage-index` | V1 | – | – | `storageIndexEdition` | Home block and menu card only |
| Resources | `/resources` | V1 | Template | 2 | – | Mega-menu only |
| Market Insights (blog) | `/resources/market-insights` | V1 | Template | 3 | `article` | Home cards only |
| Blog article | `/resources/market-insights/[slug]` | V1 | Template | 3 | `article` | Not designed |
| Methodologies | `/resources/methodologies` | V1 | Template | 3 | to model | Not designed |
| Events & webinars | `/resources/events-and-webinars` | V1 | Template | – | to model | Not designed |
| About | `/about` | V1 | – | – | to model | Not designed |
| Team | `/about/team` | V1 | – | – | to model | Not designed |
| Security and expertise | `/about/security-and-expertise` | **V2** | Template | – | to model | Not designed |
| Press & Media Kit | `/about/press-media-kit` | **V2** | Template | – | to model | Not designed |
| Careers | external: Welcome to the Jungle | – | Link | – | `navigation` | Menu entry |
| Login | to confirm (data platform URL) | – | – | – | `navigation.loginHref` | Menu entry |
| Contact us | `/contact-us` | V1 | Template | – | to model | Home contact block |
| Customer stories (listing) | `/customer-stories` | **V2** | Template | – | `customerStory` | Home cards only |
| Customer story (detail) | `/customer-stories/[slug]` | V1 | Template | – | `customerStory` | Not designed |

## Things to settle before building
1. **Customer stories.** The home page launches with three story cards that all link to a detail page, but the spreadsheet lists the *listing* as V2 and only "Customer #1" as V1. Either build three detail pages for launch, or point the cards somewhere else for now.
2. **V2 pages in the menu.** Security and expertise and Press & Media Kit are V2. Hide their menu entries until the pages exist (edit `navigation` in the Studio) so no link returns a 404.
3. **Tablet.** Only 1440 px (desktop) and 390 px (phone) are designed. Tablet widths are an interpolation; flag anything that looks wrong rather than guessing.
4. The spreadsheet spells "Price Forecas" (typo); the proposed URL uses `price-forecast`.
