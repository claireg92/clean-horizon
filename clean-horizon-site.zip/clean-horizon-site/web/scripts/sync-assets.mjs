// Copies ../assets/{brand,images,logos} into public/ so the site can serve them.
// public/brand, public/images and public/logos are git-ignored: ../assets is the single source.
// Note: in Sanity mode, logos are served from the Sanity CDN, and only logos flagged
// "approvedForPublicUse" are queried. The local copies are for sample-data mode only,
// so do not deploy a build made from the sample data.
import {cpSync, mkdirSync} from 'node:fs'
import {dirname, join} from 'node:path'
import {fileURLToPath} from 'node:url'

const web = join(dirname(fileURLToPath(import.meta.url)), '..')
const assets = join(web, '..', 'assets')
for (const dir of ['brand', 'images', 'logos']) {
  mkdirSync(join(web, 'public', dir), {recursive: true})
  cpSync(join(assets, dir), join(web, 'public', dir), {recursive: true})
}
console.log('assets synced to public/')
