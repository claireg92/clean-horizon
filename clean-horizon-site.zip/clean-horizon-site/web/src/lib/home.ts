import {client, hasSanity} from './sanity'
import {HOME_QUERY} from './queries'
import type {HomeData, LogoItem, Story} from './types'
import sample from '../../../content/home.json'
import manifest from '../../../assets/logos/logos.manifest.json'

const logoFile = (name: string): string | undefined => {
  const m = (manifest as {name: string; file: string}[]).find((l) => l.name === name)
  return m ? `/logos/${m.file}` : undefined
}

/** Business rule: client-sourced figures and quotes are hidden until a person ticks "approved" in the Studio. */
function onlyApproved(story: Story): Story {
  return {
    ...story,
    quote: story.quote && story.quote.approved !== false ? story.quote : undefined,
    stats: story.stats.filter((s) => s.approved !== false),
  }
}

/** Local mode: build the HomeData shape from content/home.json (no Sanity project needed). */
function fromSample(): HomeData {
  const h = sample.home
  const marquee: LogoItem[] = (manifest as any[])
    .filter((l) => l.showInMarquee)
    .sort((a, b) => a.marqueeOrder - b.marqueeOrder)
    .map((l) => ({name: l.name, src: `/logos/${l.file}`}))
  const stories: Story[] = sample.customerStories
    .filter((s: any) => !s.hiddenAtLaunch)
    .slice(0, 3)
    .map((s: any) => ({
      slug: s.slug,
      title: s.title,
      client: s.client,
      tags: s.tags,
      logos: s.logos.map((n: string) => ({name: n, src: logoFile(n)})),
      summary: s.summary,
      quote: s.quote ? {text: s.quote.text, author: s.quote.author, role: s.quote.role} : undefined,
      project: s.project,
      stats: s.stats.map((x: any) => ({value: x.value, label: x.label})),
      featured: s.featured,
      href: `/customer-stories/${s.slug}`,
    }))
  return {
    newsBanner: h.newsBanner,
    hero: {...h.hero, imageUrl: '/images/hero-battery-container.webp', imageAlt: 'Battery energy storage container on a renewable site'},
    clients: {title: h.clients.title, logos: marquee},
    decisions: h.decisions,
    markets: h.markets,
    offers: {
      title: h.offers.title,
      allLink: h.offers.allLink,
      supplierPrefix: h.offers.supplierLine.prefix,
      supplierLink: {label: h.offers.supplierLine.label, href: h.offers.supplierLine.href},
      items: sample.offers.map((o: any) => ({
        title: o.title, kind: o.kind.toLowerCase(), order: o.order, lead: o.lead, text: o.text,
        bullets: o.bullets, where: o.where, cta: {label: o.cta, href: o.href},
      })),
    },
    stories: {title: 'Customer stories: how storage projects were decided, financed and built', allLink: {label: 'All customer stories →', href: '/customer-stories'}, items: stories},
    pillars: h.pillars,
    faq: {title: 'Frequently asked questions', items: sample.faq.map((f: any) => ({question: f.q, answer: f.a}))},
  }
}

export async function getHome(): Promise<HomeData> {
  if (!hasSanity || !client) return fromSample()
  const r: any = await client.fetch(HOME_QUERY)
  if (!r.home) throw new Error('No homePage document found in Sanity. Publish it in the Studio first.')
  const marquee: LogoItem[] = r.marqueeLogos.map((l: any) => ({name: l.name, src: l.src}))
  return {
    newsBanner: {...r.settings?.newsBanner},
    hero: r.home.hero,
    clients: {title: r.home.clients.title, logos: marquee},
    decisions: {...r.home.decisions, items: r.home.decisions.items.map((d: any, i: number) => ({...d, n: String(i + 1).padStart(2, '0')}))},
    markets: r.home.markets,
    offers: {
      title: r.home.offers.title, allLink: r.home.offers.allLink,
      supplierPrefix: r.home.offers.supplierPrefix, supplierLink: r.home.offers.supplierLink,
      items: r.home.offers.items,
    },
    stories: {
      ...r.home.stories,
      items: r.home.stories.items.map((s: any) => onlyApproved({...s, href: `/customer-stories/${s.slug}`})),
    },
    pillars: r.home.pillars,
    faq: r.home.faq,
  }
}
