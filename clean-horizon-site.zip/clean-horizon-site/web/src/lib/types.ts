// Shape returned by getHome(): same whether data comes from Sanity (GROQ) or ../content/home.json.
export type Cta = {label: string; href: string}
export type Stat = {value: string; label: string; approved?: boolean}

export type LogoItem = {name: string; src?: string}

export type Story = {
  slug: string
  title: string
  client?: string
  tags: string[]
  logos: LogoItem[]
  summary?: string
  quote?: {text: string; author: string; role: string; approved?: boolean}
  project: string
  stats: Stat[]
  featured?: boolean
  href: string
}

export type Offer = {
  title: string
  kind: 'subscription' | 'advisory'
  order: number
  lead: string
  text: string
  bullets: string[]
  where: string
  cta: Cta
}

export type Faq = {question: string; answer: string}

export type HomeData = {
  newsBanner: {eyebrow: string; title: string; summary: string; cta: Cta}
  hero: {kicker: string; h1: string; sub: string; primaryCta: Cta; secondaryCta: Cta; tagline: string; imageUrl?: string; imageAlt?: string}
  clients: {title: string; logos: LogoItem[]}
  decisions: {title: string; intro: string; items: {n: string; label: string; question: string; text: string; askedBy: string; href: string}[]; closing: string}
  markets: {title: string; intro: string; columns: {label: string; bullets: string[]; footnote?: string}[]; body: string; primaryCta: Cta; secondaryCta: Cta; note: string}
  offers: {title: string; allLink: Cta; items: Offer[]; supplierPrefix: string; supplierLink: Cta}
  stories: {title: string; allLink: Cta; items: Story[]}
  pillars: {title: string; items: {key: 'close' | 'storage' | 'fullcycle' | 'transparency'; title: string; text: string}[]}
  faq: {title: string; items: Faq[]}
}
