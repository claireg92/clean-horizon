// GROQ for the home page. The shape matches HomeData (src/lib/types.ts).
export const HOME_QUERY = /* groq */ `{
  "home": *[_type == "homePage"][0]{
    ...,
    hero{..., "imageUrl": image.asset->url, "imageAlt": image.alt},
    offers{..., items[]->{title, "kind": kind, order, lead, text, bullets, where, cta}},
    stories{..., items[]->{
      "slug": slug.current, title, client, tags, summary, quote, project, stats, featured,
      "logos": logos[]->{name, "src": logo.asset->url}
    }},
    faq{title, items[]->{question, answer}}
  },
  "settings": *[_type == "siteSettings"][0],
  "marqueeLogos": *[_type == "clientLogo" && approvedForPublicUse == true && showInMarquee == true]
    | order(select(category == "lender" => 0, 1) asc, marqueeOrder asc){name, category, "src": logo.asset->url},
  "latestIndex": *[_type == "storageIndexEdition"] | order(month desc)[0]{month, headline, analyst, "slug": slug.current},
  "latestArticles": *[_type == "article"] | order(publishedAt desc)[0...2]{title, category, author, publishedAt, "slug": slug.current}
}`
