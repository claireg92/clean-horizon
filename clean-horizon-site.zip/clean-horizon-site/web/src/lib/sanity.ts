import {createClient} from '@sanity/client'
import imageUrlBuilder from '@sanity/image-url'

const projectId = import.meta.env.PUBLIC_SANITY_PROJECT_ID as string | undefined
const dataset = (import.meta.env.PUBLIC_SANITY_DATASET as string | undefined) ?? 'production'

export const hasSanity = Boolean(projectId)

export const client = hasSanity
  ? createClient({
      projectId,
      dataset,
      apiVersion: (import.meta.env.SANITY_API_VERSION as string | undefined) ?? '2025-01-01',
      useCdn: true,
      token: import.meta.env.SANITY_READ_TOKEN as string | undefined,
    })
  : null

const builder = hasSanity ? imageUrlBuilder({projectId: projectId!, dataset}) : null

/** Returns a URL for a Sanity image field, or undefined when Sanity is not configured. */
export function urlFor(source: unknown, width?: number): string | undefined {
  if (!builder || !source) return undefined
  let img = builder.image(source as any).auto('format')
  if (width) img = img.width(width)
  return img.url()
}
