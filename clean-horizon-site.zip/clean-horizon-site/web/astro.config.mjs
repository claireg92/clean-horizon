import {defineConfig} from 'astro/config'

// Static output: pages are built from Sanity at build time.
// Rebuild on publish with a Sanity webhook -> your host's build hook (see docs/04).
export default defineConfig({
  site: 'https://www.cleanhorizon.com', // TO CONFIRM: production domain
  output: 'static',
  trailingSlash: 'never',
})
