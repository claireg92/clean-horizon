import {defineField, defineType} from 'sanity'

/** A button or text link. `href` accepts an internal path ("/contact-us") or a full URL. */
export const cta = defineType({
  name: 'cta',
  title: 'Link / button',
  type: 'object',
  fields: [
    defineField({name: 'label', type: 'string', validation: (r) => r.required()}),
    defineField({name: 'href', type: 'string', description: 'Internal path (/contact-us) or full URL.', validation: (r) => r.required()}),
  ],
  preview: {select: {title: 'label', subtitle: 'href'}},
})

export const seo = defineType({
  name: 'seo',
  title: 'SEO',
  type: 'object',
  fields: [
    defineField({name: 'title', type: 'string', description: '50–60 characters.', validation: (r) => r.max(70)}),
    defineField({name: 'description', type: 'text', rows: 3, description: '140–160 characters.', validation: (r) => r.max(180)}),
    defineField({name: 'image', title: 'Social share image', type: 'image'}),
    defineField({name: 'noindex', type: 'boolean', initialValue: false}),
  ],
})

/** A figure with its label, e.g. "120 MW" / "240 MWh battery energy storage system". */
export const stat = defineType({
  name: 'stat',
  title: 'Figure',
  type: 'object',
  fields: [
    defineField({name: 'value', type: 'string', validation: (r) => r.required()}),
    defineField({name: 'label', type: 'string', validation: (r) => r.required()}),
    defineField({
      name: 'approved',
      title: 'Approved by the client',
      type: 'boolean',
      initialValue: false,
      description: 'Client-sourced figures must be approved before they are shown on the live site.',
    }),
  ],
  preview: {select: {title: 'value', subtitle: 'label'}},
})

export const portableText = defineType({
  name: 'portableText',
  title: 'Rich text',
  type: 'array',
  of: [
    {type: 'block'},
    {type: 'image', options: {hotspot: true}, fields: [{name: 'alt', type: 'string', title: 'Alt text'}]},
  ],
})

export const objectTypes = [cta, seo, stat, portableText]
