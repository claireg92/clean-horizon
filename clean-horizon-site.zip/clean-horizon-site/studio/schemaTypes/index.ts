import {objectTypes} from './objects'
import {documentTypes} from './documents'
import {singletonTypes} from './singletons'

export const schemaTypes = [...objectTypes, ...documentTypes, ...singletonTypes]
