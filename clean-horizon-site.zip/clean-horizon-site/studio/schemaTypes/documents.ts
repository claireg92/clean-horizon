import {defineField, defineType} from 'sanity'

export const offer = defineType({
  name: 'offer',
  title: 'Offer (solution card)',
  type: 'document',
  fields: [
    defineField({name: 'title', type: 'string', validation: (r) => r.required()}),
    defineField({name: 'slug', type: 'slug', options: {source: 'title'}, validation: (r) => r.required()}),
    defineField({name: 'kind', type: 'string', options: {list: [{title: 'Subscription', value: 'subscription'}, {title: 'Advisory', value: 'advisory'}]}, validation: (r) => r.required()}),
    defineField({name: 'order', type: 'number', validation: (r) => r.required().integer()}),
    defineField({name: 'lead', title: 'Lead sentence (bold)', type: 'string'}),
    defineField({name: 'text', type: 'text', rows: 3}),
    defineField({name: 'bullets', type: 'array', of: [{type: 'string'}], validation: (r) => r.max(3)}),
    defineField({name: 'where', type: 'string', description: 'Completes "Where: …"'}),
    defineField({name: 'cta', type: 'cta', description: 'One single CTA per card (decision).'}),
  ],
  orderings: [{title: 'Order', name: 'order', by: [{field: 'order', direction: 'asc'}]}],
  preview: {select: {title: 'title', subtitle: 'kind'}},
})

export const clientLogo = defineType({
  name: 'clientLogo',
  title: 'Client logo',
  type: 'document',
  fields: [
    defineField({name: 'name', type: 'string', validation: (r) => r.required()}),
    defineField({name: 'logo', type: 'image', validation: (r) => r.required()}),
    defineField({name: 'category', type: 'string', options: {list: [{title: 'Bank / lender / fund', value: 'lender'}, {title: 'IPP / developer', value: 'ipp'}]}, validation: (r) => r.required()}),
    defineField({
      name: 'approvedForPublicUse',
      title: 'Approved for public use',
      type: 'boolean',
      initialValue: false,
      description: 'OFF by default. Only approved logos are returned by the website queries.',
    }),
    defineField({name: 'showInMarquee', type: 'boolean', initialValue: false}),
    defineField({name: 'marqueeOrder', type: 'number', description: 'Banks first, then IPPs (decision).'}),
  ],
  preview: {select: {title: 'name', subtitle: 'category', media: 'logo'}},
})

export const customerStory = defineType({
  name: 'customerStory',
  title: 'Customer story',
  type: 'document',
  fields: [
    defineField({name: 'title', type: 'string', validation: (r) => r.required()}),
    defineField({name: 'slug', type: 'slug', options: {source: 'title'}, validation: (r) => r.required()}),
    defineField({name: 'client', type: 'string'}),
    defineField({name: 'logos', type: 'array', of: [{type: 'reference', to: [{type: 'clientLogo'}]}], validation: (r) => r.max(3)}),
    defineField({name: 'tags', type: 'array', of: [{type: 'string'}], description: 'Pills at the top of the card, e.g. Economic, Technical, France.'}),
    defineField({name: 'summary', type: 'text', rows: 2}),
    defineField({
      name: 'quote',
      type: 'object',
      fields: [
        defineField({name: 'text', type: 'text', rows: 4}),
        defineField({name: 'author', type: 'string'}),
        defineField({name: 'role', type: 'string'}),
        defineField({name: 'approved', title: 'Approved by the client', type: 'boolean', initialValue: false}),
      ],
    }),
    defineField({name: 'project', title: 'Project name (blue band)', type: 'string'}),
    defineField({name: 'stats', type: 'array', of: [{type: 'stat'}], validation: (r) => r.max(2)}),
    defineField({name: 'featured', type: 'boolean', initialValue: false}),
    defineField({name: 'showOnHome', type: 'boolean', initialValue: false, description: 'The home page shows 3 at launch.'}),
    defineField({name: 'order', type: 'number'}),
    defineField({name: 'body', title: 'Full story (V2 page)', type: 'portableText'}),
    defineField({name: 'seo', type: 'seo'}),
  ],
  orderings: [{title: 'Order', name: 'order', by: [{field: 'order', direction: 'asc'}]}],
  preview: {select: {title: 'title', subtitle: 'client'}},
})

export const faqItem = defineType({
  name: 'faqItem',
  title: 'FAQ item',
  type: 'document',
  fields: [
    defineField({name: 'question', type: 'string', validation: (r) => r.required()}),
    defineField({name: 'answer', type: 'text', rows: 6, validation: (r) => r.required()}),
    defineField({name: 'order', type: 'number'}),
    defineField({name: 'showOnHome', type: 'boolean', initialValue: true}),
  ],
  orderings: [{title: 'Order', name: 'order', by: [{field: 'order', direction: 'asc'}]}],
  preview: {select: {title: 'question'}},
})

export const storageIndexEdition = defineType({
  name: 'storageIndexEdition',
  title: 'Storage Index edition',
  type: 'document',
  description: 'One document per monthly edition. The Storage Index page is the site’s main traffic source: keep its URL (see docs/05).',
  fields: [
    defineField({name: 'month', type: 'date', options: {dateFormat: 'YYYY-MM'}, validation: (r) => r.required()}),
    defineField({name: 'slug', type: 'slug', options: {source: (doc: any) => `storage-index-${doc.month ?? ''}`}}),
    defineField({name: 'headline', type: 'string', description: 'Headline figure of the month, in one line.'}),
    defineField({name: 'analyst', type: 'string'}),
    defineField({name: 'chart', type: 'image', fields: [{name: 'alt', type: 'string'}]}),
    defineField({name: 'summary', type: 'text', rows: 3}),
    defineField({name: 'body', type: 'portableText'}),
    defineField({name: 'seo', type: 'seo'}),
  ],
  orderings: [{title: 'Newest first', name: 'monthDesc', by: [{field: 'month', direction: 'desc'}]}],
  preview: {select: {title: 'headline', subtitle: 'month'}},
})

export const article = defineType({
  name: 'article',
  title: 'Article or report',
  type: 'document',
  fields: [
    defineField({name: 'title', type: 'string', validation: (r) => r.required()}),
    defineField({name: 'slug', type: 'slug', options: {source: 'title'}, validation: (r) => r.required()}),
    defineField({name: 'category', type: 'string', options: {list: [{title: 'Market analysis', value: 'market-analysis'}, {title: 'Reports and guides', value: 'reports-guides'}]}, validation: (r) => r.required()}),
    defineField({name: 'author', type: 'string'}),
    defineField({name: 'publishedAt', type: 'datetime', validation: (r) => r.required()}),
    defineField({name: 'cover', type: 'image', fields: [{name: 'alt', type: 'string'}]}),
    defineField({name: 'excerpt', type: 'text', rows: 3}),
    defineField({name: 'body', type: 'portableText'}),
    defineField({name: 'seo', type: 'seo'}),
  ],
  orderings: [{title: 'Newest first', name: 'dateDesc', by: [{field: 'publishedAt', direction: 'desc'}]}],
  preview: {select: {title: 'title', subtitle: 'category', media: 'cover'}},
})

export const documentTypes = [offer, clientLogo, customerStory, faqItem, storageIndexEdition, article]
