import {defineField, defineType} from 'sanity'

export const siteSettings = defineType({
  name: 'siteSettings',
  title: 'Site settings',
  type: 'document',
  fields: [
    defineField({name: 'siteName', type: 'string', initialValue: 'Clean Horizon'}),
    defineField({name: 'defaultSeo', type: 'seo'}),
    defineField({
      name: 'newsBanner',
      title: 'News banner (top of every page)',
      type: 'object',
      fields: [
        defineField({name: 'enabled', type: 'boolean', initialValue: true}),
        defineField({name: 'eyebrow', type: 'string'}),
        defineField({name: 'title', type: 'string'}),
        defineField({name: 'summary', type: 'string'}),
        defineField({name: 'cta', type: 'cta'}),
      ],
    }),
    defineField({name: 'contactEmail', type: 'string'}),
    defineField({name: 'phone', type: 'string'}),
    defineField({name: 'offices', type: 'array', of: [{type: 'string'}]}),
    defineField({name: 'linkedin', type: 'url'}),
    defineField({name: 'youtube', type: 'url'}),
    defineField({name: 'footerTagline', type: 'string'}),
    defineField({name: 'footerSubline', type: 'string'}),
    defineField({name: 'isoBadge', type: 'image', fields: [{name: 'caption', type: 'string'}]}),
    defineField({name: 'legalLinks', type: 'array', of: [{type: 'cta'}]}),
  ],
  preview: {prepare: () => ({title: 'Site settings'})},
})

const menuItem = defineField({
  name: 'items',
  type: 'array',
  of: [
    {
      type: 'object',
      name: 'menuItem',
      fields: [
        defineField({name: 'label', type: 'string', validation: (r) => r.required()}),
        defineField({name: 'description', type: 'string'}),
        defineField({name: 'href', type: 'string', validation: (r) => r.required()}),
      ],
      preview: {select: {title: 'label', subtitle: 'description'}},
    },
  ],
})

export const navigation = defineType({
  name: 'navigation',
  title: 'Navigation and menus',
  type: 'document',
  fields: [
    defineField({
      name: 'topLevel',
      title: 'Top-level entries (in order)',
      description: 'Order from the design: Solutions, Customer stories, Resources, About. Panels open a mega menu; links go straight to a page.',
      type: 'array',
      of: [
        {
          type: 'object',
          name: 'entry',
          fields: [
            defineField({name: 'label', type: 'string', validation: (r) => r.required()}),
            defineField({name: 'href', type: 'string', description: 'Leave empty if the entry opens a panel.'}),
            defineField({
              name: 'groups',
              title: 'Panel columns',
              type: 'array',
              of: [
                {
                  type: 'object',
                  name: 'group',
                  fields: [defineField({name: 'title', type: 'string'}), menuItem],
                  preview: {select: {title: 'title'}},
                },
              ],
            }),
          ],
          preview: {select: {title: 'label'}},
        },
      ],
    }),
    defineField({name: 'featuredCard', title: 'Featured card in the Solutions panel', type: 'object', fields: [
      defineField({name: 'source', type: 'string', options: {list: [{title: 'Latest Storage Index edition', value: 'storageIndex'}, {title: 'Latest article', value: 'article'}]}}),
    ]}),
    defineField({name: 'loginHref', type: 'string'}),
    defineField({name: 'headerCta', type: 'cta', description: 'Header button, e.g. “Talk to an expert”.'}),
  ],
  preview: {prepare: () => ({title: 'Navigation and menus'})},
})

const sectionTitle = (name = 'title') => defineField({name, type: 'string'})

export const homePage = defineType({
  name: 'homePage',
  title: 'Home page',
  type: 'document',
  groups: [
    {name: 'top', title: 'Hero and clients', default: true},
    {name: 'offer', title: 'Offer and proof'},
    {name: 'insight', title: 'Storage Index and coverage'},
    {name: 'convert', title: 'Contact and FAQ'},
    {name: 'seo', title: 'SEO'},
  ],
  fields: [
    defineField({name: 'hero', group: 'top', type: 'object', fields: [
      defineField({name: 'kicker', type: 'string'}),
      defineField({name: 'h1', type: 'string', validation: (r) => r.required()}),
      defineField({name: 'sub', type: 'text', rows: 3}),
      defineField({name: 'image', type: 'image', options: {hotspot: true}, fields: [{name: 'alt', type: 'string'}]}),
      defineField({name: 'primaryCta', type: 'cta'}),
      defineField({name: 'secondaryCta', type: 'cta'}),
      defineField({name: 'tagline', type: 'string'}),
    ]}),
    defineField({name: 'clients', group: 'top', type: 'object', description: 'Marquee: banks first, then IPPs. Logos come from “Client logos” (approved + showInMarquee).', fields: [sectionTitle()]}),
    defineField({name: 'decisions', group: 'offer', type: 'object', fields: [
      sectionTitle(),
      defineField({name: 'intro', type: 'text', rows: 3}),
      defineField({name: 'items', type: 'array', validation: (r) => r.length(4), of: [{type: 'object', name: 'decision', fields: [
        defineField({name: 'label', type: 'string'}),
        defineField({name: 'question', type: 'string'}),
        defineField({name: 'text', type: 'string'}),
        defineField({name: 'askedBy', type: 'string'}),
        defineField({name: 'href', type: 'string'}),
      ], preview: {select: {title: 'question', subtitle: 'label'}}}]}),
      defineField({name: 'closing', type: 'string'}),
    ]}),
    defineField({name: 'markets', group: 'offer', type: 'object', fields: [
      sectionTitle(),
      defineField({name: 'intro', type: 'text', rows: 3}),
      defineField({name: 'columns', type: 'array', validation: (r) => r.length(2), of: [{type: 'object', name: 'column', fields: [
        defineField({name: 'label', type: 'string'}),
        defineField({name: 'bullets', type: 'array', of: [{type: 'string'}]}),
        defineField({name: 'footnote', type: 'string'}),
      ], preview: {select: {title: 'label'}}}]}),
      defineField({name: 'body', type: 'text', rows: 4}),
      defineField({name: 'primaryCta', type: 'cta'}),
      defineField({name: 'secondaryCta', type: 'cta'}),
      defineField({name: 'note', type: 'string'}),
    ]}),
    defineField({name: 'offers', group: 'offer', type: 'object', fields: [
      sectionTitle(),
      defineField({name: 'allLink', type: 'cta'}),
      defineField({name: 'items', type: 'array', of: [{type: 'reference', to: [{type: 'offer'}]}], validation: (r) => r.length(4)}),
      defineField({name: 'supplierPrefix', type: 'string'}),
      defineField({name: 'supplierLink', type: 'cta'}),
    ]}),
    defineField({name: 'stories', group: 'offer', type: 'object', fields: [
      sectionTitle(),
      defineField({name: 'allLink', type: 'cta'}),
      defineField({name: 'items', description: 'Exactly 3 at launch (3-column grid on desktop; featured first, then 2 compact cards on mobile).', type: 'array', of: [{type: 'reference', to: [{type: 'customerStory'}]}], validation: (r) => r.length(3)}),
    ]}),
    defineField({name: 'storageIndex', group: 'insight', type: 'object', description: 'Edition shown in the card comes from the latest “Storage Index edition”. No sign-up form for now.', fields: [
      defineField({name: 'eyebrow', type: 'string'}),
      sectionTitle(),
      defineField({name: 'text', type: 'text', rows: 3}),
      defineField({name: 'primaryCta', type: 'cta'}),
      defineField({name: 'secondaryCta', type: 'cta'}),
    ]}),
    defineField({name: 'pillars', group: 'insight', type: 'object', fields: [
      sectionTitle(),
      defineField({name: 'items', type: 'array', validation: (r) => r.length(4), of: [{type: 'object', name: 'pillar', fields: [
        defineField({name: 'key', type: 'string', options: {list: ['close', 'storage', 'fullcycle', 'transparency']}}),
        defineField({name: 'title', type: 'string'}),
        defineField({name: 'text', type: 'text', rows: 3}),
      ], preview: {select: {title: 'title', subtitle: 'key'}}}]}),
    ]}),
    defineField({name: 'coverage', group: 'insight', type: 'object', fields: [
      defineField({name: 'eyebrow', type: 'string'}),
      sectionTitle(),
      defineField({name: 'levels', type: 'array', of: [{type: 'object', name: 'level', fields: [defineField({name: 'title', type: 'string'}), defineField({name: 'text', type: 'string'})], preview: {select: {title: 'title', subtitle: 'text'}}}]}),
      defineField({name: 'countries', type: 'array', of: [{type: 'string'}], description: '18 countries. The map file must show the same 18.'}),
      defineField({name: 'map', type: 'image', fields: [{name: 'alt', type: 'string'}]}),
    ]}),
    defineField({name: 'publications', group: 'insight', type: 'object', fields: [sectionTitle(), defineField({name: 'allLink', type: 'cta'})]}),
    defineField({name: 'newsletter', group: 'convert', type: 'object', fields: [sectionTitle(), defineField({name: 'text', type: 'text', rows: 2})]}),
    defineField({name: 'contact', group: 'convert', type: 'object', fields: [
      defineField({name: 'stats', type: 'array', validation: (r) => r.length(3), of: [{type: 'stat'}]}),
      sectionTitle(),
      defineField({name: 'text', type: 'text', rows: 3}),
      defineField({name: 'formNote', type: 'string', description: 'Reply-time commitment, to validate with the sales team.'}),
    ]}),
    defineField({name: 'faq', group: 'convert', type: 'object', fields: [
      sectionTitle(),
      defineField({name: 'items', type: 'array', of: [{type: 'reference', to: [{type: 'faqItem'}]}]}),
    ]}),
    defineField({name: 'seo', group: 'seo', type: 'seo'}),
  ],
  preview: {prepare: () => ({title: 'Home page'})},
})

export const singletonTypes = [siteSettings, navigation, homePage]
