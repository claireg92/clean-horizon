// Seeds the Sanity dataset from ../content/home.json and ../assets/logos.
// UNTESTED against a live project: run it first on a throw-away dataset.
//
//   SANITY_PROJECT_ID=xxxx SANITY_DATASET=staging SANITY_WRITE_TOKEN=sk... node scripts/seed.mjs
//
// Safe to re-run: every document has a fixed _id and uses createOrReplace.
import {createClient} from '@sanity/client'
import {readFileSync, createReadStream} from 'node:fs'
import {dirname, join} from 'node:path'
import {fileURLToPath} from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const root = join(here, '..', '..')
const data = JSON.parse(readFileSync(join(root, 'content', 'home.json'), 'utf8'))
const logosDir = join(root, 'assets', 'logos')
const manifest = JSON.parse(readFileSync(join(logosDir, 'logos.manifest.json'), 'utf8'))

const {SANITY_PROJECT_ID, SANITY_DATASET = 'production', SANITY_WRITE_TOKEN} = process.env
if (!SANITY_PROJECT_ID || !SANITY_WRITE_TOKEN) {
  console.error('Set SANITY_PROJECT_ID and SANITY_WRITE_TOKEN (and SANITY_DATASET).')
  process.exit(1)
}
const client = createClient({projectId: SANITY_PROJECT_ID, dataset: SANITY_DATASET, apiVersion: '2025-01-01', token: SANITY_WRITE_TOKEN, useCdn: false})

const slugify = (s) => s.normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[’']/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
const key = (i) => `k${i}`
const withKeys = (arr) => arr.map((x, i) => (typeof x === 'object' ? {_key: key(i), ...x} : x))
const cta = (c) => (c ? {label: c.label, href: c.href} : undefined)
const ref = (id, i) => ({_type: 'reference', _key: key(i), _ref: id})

// 1. Logos (uploads images). approvedForPublicUse stays FALSE: someone must tick it per logo.
const logoIds = {}
for (const l of manifest) {
  const asset = await client.assets.upload('image', createReadStream(join(logosDir, l.file)), {filename: l.file.split('/').pop()})
  const _id = `clientLogo.${slugify(l.name)}`
  logoIds[l.name] = _id
  await client.createOrReplace({
    _id, _type: 'clientLogo', name: l.name, category: l.category,
    logo: {_type: 'image', asset: {_type: 'reference', _ref: asset._id}},
    approvedForPublicUse: false, showInMarquee: l.showInMarquee, marqueeOrder: l.marqueeOrder ?? undefined,
  })
  console.log('logo', l.name)
}

// 2. Offers
const offerIds = []
for (const o of data.offers) {
  const _id = `offer.${o.slug}`
  offerIds.push(_id)
  await client.createOrReplace({
    _id, _type: 'offer', title: o.title, slug: {_type: 'slug', current: o.slug}, kind: o.kind.toLowerCase(), order: o.order,
    lead: o.lead, text: o.text, bullets: o.bullets, where: o.where, cta: {label: o.cta, href: o.href},
  })
}

// 3. Customer stories (the 3 shown at launch; Hertz stays unpublished for the home page)
const storyIds = []
for (const s of data.customerStories) {
  const _id = `customerStory.${s.slug}`
  const onHome = !s.hiddenAtLaunch
  if (onHome) storyIds.push(_id)
  await client.createOrReplace({
    _id, _type: 'customerStory', title: s.title, slug: {_type: 'slug', current: s.slug}, client: s.client,
    logos: s.logos.map((n, i) => ref(logoIds[n], i)), tags: s.tags, summary: s.summary,
    quote: s.quote ? {text: s.quote.text, author: s.quote.author, role: s.quote.role, approved: false} : undefined,
    project: s.project,
    stats: s.stats.map((x, i) => ({_key: key(i), _type: 'stat', value: x.value, label: x.label, approved: x.approvalStatus ? false : true})),
    featured: !!s.featured, showOnHome: onHome, order: s.order,
  })
}

// 4. FAQ
const faqIds = []
for (const [i, f] of data.faq.entries()) {
  const _id = `faqItem.${i + 1}`
  faqIds.push(_id)
  await client.createOrReplace({_id, _type: 'faqItem', question: f.q, answer: f.a, order: i + 1, showOnHome: true})
}

// 5. Site settings
const h = data.home
await client.createOrReplace({
  _id: 'siteSettings', _type: 'siteSettings', siteName: 'Clean Horizon',
  newsBanner: {enabled: true, eyebrow: h.newsBanner.eyebrow, title: h.newsBanner.title, summary: h.newsBanner.summary, cta: cta(h.newsBanner.cta)},
  contactEmail: h.contact.email, phone: h.contact.phone, offices: h.footer.offices,
  linkedin: h.footer.linkedin, youtube: h.footer.youtube, footerTagline: h.footer.tagline, footerSubline: h.footer.sub,
})

// 6. Navigation
const nav = data.navigation
const items = (list) => list.map(([label, description, href], i) => ({_key: key(i), label, description, href}))
await client.createOrReplace({
  _id: 'navigation', _type: 'navigation',
  topLevel: [
    {_key: 'solutions', label: 'Solutions', groups: [
      {_key: 'g1', title: 'Solutions', items: items(nav.solutions)},
      {_key: 'g2', title: 'Inside Data & Tools', items: items(nav.insideDataTools)},
    ]},
    {_key: 'stories', label: 'Customer stories', href: '/customer-stories'},
    {_key: 'resources', label: 'Resources', groups: Object.entries(nav.resources).map(([title, l], i) => ({_key: key(i), title, items: items(l)}))},
    {_key: 'about', label: 'About', groups: Object.entries(nav.about).map(([title, l], i) => ({_key: key(i), title, items: items(l)}))},
  ],
  featuredCard: {source: 'storageIndex'}, loginHref: '/login', headerCta: {label: 'Talk to an expert', href: '/contact-us'},
})

// 7. Home page
await client.createOrReplace({
  _id: 'homePage', _type: 'homePage',
  hero: {kicker: h.hero.kicker, h1: h.hero.h1, sub: h.hero.sub, primaryCta: cta(h.hero.primaryCta), secondaryCta: cta(h.hero.secondaryCta), tagline: h.hero.tagline},
  clients: {title: h.clients.title},
  decisions: {title: h.decisions.title, intro: h.decisions.intro, closing: h.decisions.closing,
    items: h.decisions.items.map((d, i) => ({_key: key(i), label: d.label, question: d.question, text: d.text, askedBy: d.askedBy, href: d.href}))},
  markets: {title: h.markets.title, intro: h.markets.intro, body: h.markets.body, note: h.markets.note,
    columns: h.markets.columns.map((c, i) => ({_key: key(i), ...c})), primaryCta: cta(h.markets.primaryCta), secondaryCta: cta(h.markets.secondaryCta)},
  offers: {title: h.offers.title, allLink: cta(h.offers.allLink), items: offerIds.map(ref), supplierPrefix: h.offers.supplierLine.prefix,
    supplierLink: {label: h.offers.supplierLine.label, href: h.offers.supplierLine.href}},
  stories: {title: 'Customer stories: how storage projects were decided, financed and built', allLink: {label: 'All customer stories →', href: '/customer-stories'}, items: storyIds.map(ref)},
  storageIndex: {eyebrow: h.storageIndex.eyebrow, title: h.storageIndex.title, text: h.storageIndex.text, primaryCta: cta(h.storageIndex.primaryCta), secondaryCta: cta(h.storageIndex.secondaryCta)},
  pillars: {title: h.pillars.title, items: h.pillars.items.map((p, i) => ({_key: key(i), key: p.key, title: p.title, text: p.text}))},
  coverage: {eyebrow: h.coverage.eyebrow, title: h.coverage.title, countries: h.coverage.countries,
    levels: h.coverage.levels.map((l, i) => ({_key: key(i), title: l.title, text: l.text}))},
  publications: {title: h.publications.title, allLink: cta(h.publications.allLink)},
  newsletter: {title: h.newsletter.title, text: h.newsletter.text},
  contact: {title: h.contact.title, text: h.contact.text, formNote: h.contact.form.note,
    stats: h.contact.stats.map((s, i) => ({_key: key(i), _type: 'stat', value: s.value, label: s.label, approved: true}))},
  faq: {title: 'Frequently asked questions', items: faqIds.map(ref)},
})
console.log('Seed complete. Upload the hero image and coverage map in the Studio, then approve logos one by one.')
