import type {StructureResolver} from 'sanity/structure'

const single = (S: Parameters<StructureResolver>[0], type: string, title: string) =>
  S.listItem().title(title).id(type).child(S.document().schemaType(type).documentId(type))

export const structure: StructureResolver = (S) =>
  S.list()
    .title('Content')
    .items([
      S.listItem().title('Site').child(
        S.list().title('Site').items([
          single(S, 'siteSettings', 'Site settings'),
          single(S, 'navigation', 'Navigation and menus'),
        ]),
      ),
      single(S, 'homePage', 'Home page'),
      S.divider(),
      S.documentTypeListItem('offer').title('Offers (solutions cards)'),
      S.documentTypeListItem('customerStory').title('Customer stories'),
      S.documentTypeListItem('clientLogo').title('Client logos'),
      S.documentTypeListItem('storageIndexEdition').title('Storage Index editions'),
      S.documentTypeListItem('article').title('Articles and reports'),
      S.documentTypeListItem('faqItem').title('FAQ'),
    ])
